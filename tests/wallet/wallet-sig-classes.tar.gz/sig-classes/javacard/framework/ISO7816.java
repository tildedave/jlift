package javacard.framework;

public interface ISO7816 {
    int __JIF_SIG_OF_JAVA_CLASS$20030619 = 0;
    short SW_NO_ERROR = 0;
    short SW_BYTES_REMAINING_00 = 0;
    short SW_WRONG_LENGTH = 0;
    short SW_SECURITY_STATUS_NOT_SATISFIED = 0;
    short SW_FILE_INVALID = 0;
    short SW_DATA_INVALID = 0;
    short SW_CONDITIONS_NOT_SATISFIED = 0;
    short SW_COMMAND_NOT_ALLOWED = 0;
    short SW_APPLET_SELECT_FAILED = 0;
    short SW_WRONG_DATA = 0;
    short SW_FUNC_NOT_SUPPORTED = 0;
    short SW_FILE_NOT_FOUND = 0;
    short SW_RECORD_NOT_FOUND = 0;
    short SW_INCORRECT_P1P2 = 0;
    short SW_WRONG_P1P2 = 0;
    short SW_CORRECT_LENGTH_00 = 0;
    short SW_INS_NOT_SUPPORTED = 0;
    short SW_CLA_NOT_SUPPORTED = 0;
    short SW_UNKNOWN = 0;
    short SW_FILE_FULL = 0;
    short SW_LOGICAL_CHANNEL_NOT_SUPPORTED = 0;
    short SW_SECURE_MESSAGING_NOT_SUPPORTED = 0;
    short SW_WARNING_STATE_UNCHANGED = 0;
    byte OFFSET_CLA = 0;
    byte OFFSET_INS = 0;
    byte OFFSET_P1 = 0;
    byte OFFSET_P2 = 0;
    byte OFFSET_LC = 0;
    byte OFFSET_CDATA = 0;
    byte CLA_ISO7816 = 0;
    byte INS_SELECT = 0;
    byte INS_EXTERNAL_AUTHENTICATE = 0;
    String jlc$CompilerVersion$jif = "3.0.0";
    long jlc$SourceLastModified$jif = 1185979213000L;
    String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAJWae3AbxR3Hz7Ljd+JH7MQksWPnQeKY2BYhD+o2RciSI0eW" +
       "FEmOE0MQ59PJnHN6\n9O5ky4F0oJQkhD7ClDCkQ4ASSnm4JUDrzjAdQgfakn" +
       "aYDu4U6BAoBUKZAZpCYZLOUKa/3dNJp9vT\nZfPH73Q6/fbx+e5vf7u62ZlP" +
       "mHmyxLROCLFuZTrFy92DQizASjIfDSTF6TA8inA//bT2q/Hfzmdt\nTLmXqW" +
       "LTyk1JSVCmFabeO8FOsj1pRRB7vIKs9HmZWiGeEvk4n1B4Sf4W822mxMvMFx" +
       "KywiY43suO\n8aLCLPZCcz24uR4RPerBP0DpetVTEViFj7qlZFxhOrwp6Mi4" +
       "mFR6+IzSk2IlNp4tG3CKrCxDsXL8\nVGuuUk6PYQf8PSMx7VoNWUSVDxdWAe" +
       "0P9y56+vrZhlKmbpSpExIhhVUEzpkEiIwyytTG+fgY4Dii\nUT46yjQkeD4a" +
       "4iWBFYV94JhMjDKNsjCeYJW0xMtBXk6Kk8ixUU6neAm3qT0EgbgkMEppTknm" +
       "BCqP\nCbwY1b7Ni4nsuKwwi/LkKq8bPQfcagGpG2M5XitStldIRBVmubFEjn" +
       "HVdnCAohVxHkYv11RZgoUH\nTKM6jiKbGO8JKZKQGAfXeck0tKIwS4pWCk6V" +
       "KZbby47zEYVpMfoF1J/AqwoLgYooTLPRDdcEo7TE\nMEq68fGX1/7vcOB8uw" +
       "33OcpzIup/JRRqMxQK8jFe4iHU1IIX0t33eHanl9kYBpybDc6qj2P1r4e9\n" +
       "H55arvosNfHxj03wnBLhvty0rHXO8X5VKY6yVFIW0OAXkOOpEMj+0pdJwdxa" +
       "lKsR/dit/fhC8Pe7\nb32C/wgmlYcp55JiOp7wMFV8IurM3lfAvVdI8B6mTI" +
       "QPII8JIo/IK+A+xSo34ftMimGYCrDLwGqR\nKUyNJ+TfvMW+qRsmmsJcDsG5" +
       "Xpa4HjTKHCtFe2IwXfippLS3R+eYQdXVT5WUQKeXGaeMCNG2LSlG\neSnC/e" +
       "y9P97i2n7nIVsuhLIdgWDRmujONdGdbYIpKcFVLy7UAwkcRcnj42f66n+wXp" +
       "61MaWjTJUQ\nj6cVdkwE7FpWFJNTfDSi4ABq0AWrlgBqxyDWIGwjIlSkTvsU" +
       "MykxK4wxlZ97nmxOunmTjzna5vox\nGn40XE2odrVrIP5etW+1naE9gzceWl" +
       "GKnKbKQGQmg+dQC2rFKJYbzWat/vjYzV+8+EB1u1o/KtOK\nK+hAKhek3YJi" +
       "Ec722DsHO1vq/mZjbKPMgptY2ZOAwEE5h5dgduLEiaqzmUwDQ1X7nh9+4MIr" +
       "ytt4\nwKogASksBBTM7TbjZCyYP2hWGtl2slK+3i2vTTaUn3wwbmMqRpl6nN" +
       "ggee9kxTQf4iFxVguyM/sQ\nVoGC3wuTjjrD+rKTW2GWGfula7ZPy5AIfp4+" +
       "AOEeeaP7ahzMC7BPA6hdCWYHm48MPVyILk0ZHJEN\neMhRR7o9kFnHeanx3Y" +
       "ceOX/bwS0gmIeZN4k6DFrU5/18abQiHJg52lpzzzt34bFFQYEq7URBZBwP\n" +
       "1N//eA5u++BPa/fY9Em+TreEgmZqymjIx2BY4pGWb90X+NHRTw5ehwNQjcBS" +
       "BSoREizIVZ5Kj4kC\nBzcyXrkyCtMeiQx63JGQZyDid0cGHTsdEafXEQqtur" +
       "K3d0PvJvvVaCbmww8vwHxUzYiv1mw41L4x\n1gSRB+GCAw2WTDyv4EElKqF9" +
       "V3Wen8pAdUvz1eEysM4KEq44wr3QdPvRO7+sG8BVVkMkxGB7IXDT\naKiNmw" +
       "Fn7lcY6hq01o1rzq2Esyf/MwrXxcY+ZNt/ZcHrc/1PfacDt18T5WVOElIoDW" +
       "cDp1xJDoLm\naAnFLUhsQhZhE6LuTML4R1cmJfWpcYUu6/BQrcQNau555HyR" +
       "CLfx1g8/f/avs2vUFWZ5YQnCu+MX\nrf9eNXPDai0htRmRgjwLaVhlhspXvf" +
       "f4p3dUPorJ5iWn8LxertMpBes5J6RYWJe0O7RlknAtCMQJ\nnWohxi5bfd9D" +
       "aTbZ+l8O9UaHDv1anS+Sa6L72qSiJOO5hiLclS/3LnY8NvS0nt1QRudtb25p" +
       "af+M\nr8ZTJDcmKw1jkitQZFygc52FIhu6pZfbXvvw82efePwhtYPG4TQrce" +
       "LJ84/sW/PoeD6ju7Ptoo9B\nsyEbgf1yfsi+u+7Qm5//csMy3ZDhcQDkKeyo" +
       "jgq69utqLmzFtF3jqi0JcVgzJrO7obvbHvng2feC\nTTbdlnElsWvTl1G3jb" +
       "o53mHVAvZ+qatj5tvBt8dUPRsLF3tXIh3/5/SL/Jqvf/8fJruHUpjseBNS\n" +
       "gq5bMdfKXA5vBusCW4CsMIejmy4tAV+Pv3bjqz2bK9H9BnS5Cl02QoKsCY1E" +
       "fP6IKxj0B7Hr5pQq\n5NXosic7st/E12vVR3nN9xCjUPDEf4n+w9mmd0FKl+" +
       "HPlU4EzkSEjWB1yCxEkKhEaAYRrt0ddoUi\nQdeQw+Pz+AYivb2kHDIph6zD" +
       "kwk8mZCDzh9dknn6aRP6HrB6ZBb0d1DR1wH9SNAPzF6XbyC8jeQ+\nQHIf0H" +
       "EcIDgOENx0/gbu75lwXwOG7hssuO+j4m4H7pDLORz0hHdHQmFHeDgEUyEcCT" +
       "nCnpDb4+on\nhThGCnFMB3aMADtGCEHnbxDiwSIB0IjMQognqQPA7fG6Ih7f" +
       "TofXY8I9Q3LP6DhmCI4ZgpvO38D9\nTBHuhcgsuJ+n5u53hB3FuU+R3Kd0HK" +
       "cIjlMEN52/gft3Jtx9YE3ILLhfpeJeCtxOv6/fE/b4fReN\n+TlSgzkd0xzB" +
       "NEdoQOdv0OANEw02ZT+bLTR4n0qDRViDoSGHrx8L4PB6/SNm+GdJ/LM6nLME" +
       "zlkC\nn87fgP+RCf5msEXILPDPU+EvBnxHIOB1wdC7vC5nOOJ2QAYw4b9A8l" +
       "/Q8VwgeC4Q/HT+Bv6vTPjX\ngy1GVpy/pJqKf35uzUMJgKAuqSGo4VGuz9r9" +
       "YJEnfnr/QuqSBhNqtM9pQWZB3UpFjfY57mGfU53y\nw4GAPxg2GfOSNpK+TU" +
       "fTRtC0EfR0/gb6VSb09uwrvcss6Hup6Bu0ZQ7Ru/3DPhNyO0lu15HYCRI7\n" +
       "QU7nbyDfbEK+AWwJMgtyJxX5QiAPupz+YL8Vez/J3q9j6SdY+gl2On8D+2CR" +
       "UV+KzIJ9J/Woe3zA\nHkRZLmAPXEmSj5DkIzqSEYJkhCCn8zeQ7ymS45Yhsy" +
       "AXLjHHmVNPkNQTOooJgmKCoKbzN1CnTKiv\nAmtFZkF9CxV1E17Y1dFW/8+Y" +
       "/ZUr2U/C79fB7Cdg9hPwdP4G+NuLwLchs4D/ITW8R9vSFc/vR0j4\nIzqYIw" +
       "TMEQKezt8Af28R+OXILOAfph95r+Ni8CdI+BM6mBMEzAkCns7fAP+4Cfw6sH" +
       "ZkFvC/ooKv\nBvhh33aff8RHIs+SyLM6hFkCYZZApvM3IP/GBPkKsA5kFsgv" +
       "UyHXauu5e9jrJaFPk9CndRCnCYjT\nBDSdvwH6zybQ6KXFCmQW0G9SQaOXFl" +
       "7/gMfp8Eac2xw+n8t7sYA/QwpxRgd2hgA7QwhB528Q4l0T\nIRxgK5FZCPEv" +
       "KiE6tLc3rsiQKxRyDKCXdhdR4hypxDkd2TmC7ByhBJ2/QYkvTJT4GtgqZMWV" +
       "sJVQ\nKbEErfOOIH5riV5juSARoNAYMJHAZiMkgEc5AO1+sMgTP71/oQS2Sh" +
       "MJOsFWI7OQoIku+/nd7hD8\nl4X0TyI3k8jNOoRmAqGZQL4Ef91L7LKxaYXP" +
       "S7C0iASXI7OQYN0lSQDLPylBFylBlw6pi0DqIiSg\n80f3a/LIdhPktWBrkF" +
       "kgf4MKuSqLHLCTxFtJ4q06gq0EwVaCmM7fQNxfhBibBXHg0ojJ7bxtB0m8\n" +
       "Q0ewgyDYQRDT+RuIR4oQo9DutCDmLonY6ySJoyRxVEcQJQiiBDGdv4F4woS4" +
       "K7ubW2dBPElFXKvl\nMtM3U7YpEnpKBzFFQEwR0HT+Buj9JtDrsuBdFtB3Uk" +
       "HXoI179oQUyXyYZD6sYzhMMBwmmOn8DcxH\nimRstIe9woL5frqMjf6pqW9f" +
       "SeTjJPJxHcJxAuE4gUznb0A+YYK8JftaYr0F8lNUyJchZNeusCvo\ng/2rYz" +
       "i8zeULw1427CIVOEkqcFJHdJIgOkkoQOdvUCD7X6YQRWEq2TFZkVhOgZyUO3" +
       "iK4VR/fARu\nocmxye6Wpnvu7bz/dePJNwYdJGgtdtoTHyI4uOvT2gPsS3u0" +
       "Uye7oW0lmVov8pO8mG/VWMkQPtyq\nHRT7SXljtMy7pYVsX2EqslMOHbBpIY" +
       "4Hq0dauRVzN659MdVw2saU6Y6dVnmZylhaFPXHznT35SmJ\njwm411XqoZQU" +
       "+rD9RWEaycORwJW7R120zaner4Humjf6/roK0KzoD6Gpp+Z0o9Bqebzm2HV3" +
       "pxK9\nDkE7WLQwf8rMIUnsNDromLltrvXYH9jjpejgW5ks7OPVg236M4+aiq" +
       "nCI2SDQmworR7JjnAfp24Y\neDP49yeyp2pyCvMZpRsf1tZGLFdi18+va8/c" +
       "FT6iHorhRHbfPtRYpZepiCWlOKsOOzrO3VG0Nq0u\n4Z3XYodvf7+u4NBSo3" +
       "q+Na9WW/F60P3O+X1vbH/uucdMwjdXhQ4fl9FC76q1X1RceOWza3JlbW8V\n" +
       "U/H/PoDsq4IvAAA=");
    String jlc$CompilerVersion$jl = "2.0.0";
    long jlc$SourceLastModified$jl = 1185979213000L;
    String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAJV6a6wsV3ZW32v72m57xr53bI/H4/HYM57MeGp8qx/VVd0x" +
       "SKmuR9ez69mP6jA6\nqa5317Pr2dVBAX6QCYwgiZgBhCC8RkKgkXiJ8AOJhy" +
       "biHQnlR/gDAyRRiARBQoASISBU9Tnn+vra\n7nt8pK97d9Xa+1t77bXWXlVn" +
       "f/+3O09laefNJA5qJ4jz+3mdWNl9UU8zy8QCPcvU5sKF0f8rvVf+\n9h/4xb" +
       "tPdF7YdF7wIiXXc8/A4ii3Dvmm83xohVsrzVDTtMxN525kWaZipZ4eeMdGMI" +
       "42nXuZ50R6\nXqRWJltZHJSt4L2sSKz0xHl9kes8b8RRlqeFkcdplnde5HZ6" +
       "qYNF7gUg52X5e1znju1ZgZntOz/V\nucV1nrID3WkEX+GuZwGeRgTJ9noj3v" +
       "UaNVNbN6zrLk/6XmTmnS8+2uPBjN9mG4Gm69OhlbvxA6on\nI7250Ll3qVKg" +
       "Rw6o5KkXOY3oU3HRsOSd1z520EbomUQ3fN2xLvLOq4/KiZe3GqlnT2Zpu+Sd" +
       "lx8V\nO410SDuvPbJmD62WcOf5//vHxd958/ZJZ9Myglb/p5pObzzSSbZsK7" +
       "Uiw7rs+LvF/e/QWvH67U6n\nEX75EeFLGfQrf3/B/dY/+uKlzOc/QkbY7iwj" +
       "vzD+D/z6F34F/Y1nn2jVeCaJM691hQ/M/LSq4tWd\n9w5J44uvPBixvXn/+u" +
       "Y/lv+p9of/hvVfbnfu0J07RhwUYUR3nrUiE7tqP920OS+y6M6TQfPVzNz2\n" +
       "Aqud+ZNNO9Fz99Q+JJ1O5+kGn2vwfIu88xytCMi4D9/feXbe+ZHGVd/NUgNs" +
       "V9nQUxO002bdqzj1\nwYcED+1wn6pu3WqUfv3RAAoab6PiwLTSC+Ov/fq//I" +
       "ME+8d+5vYDF7pSpHGWa4r7DyjuX1F0bt06\nDf3ZD9qjNbDZxsF//Tvvvfgn" +
       "381+8XbniU3nWS8Mi1zfBs20n9eDIK4s8yI/OdDdh5z15CONgz2/\nbXytcd" +
       "uLoBno5NuNVcq086VHfer9SKSblt44yk/C88533yD+XLv87XK91I5+qVpjfP" +
       "9St+ffUb7J\n/MTPfOmJVqh6sjFy53CKoZdblkeNRbbRfD1+uP3J//WDX+i+" +
       "eTl+2+e10wBvZx/23g90vDCO/3Dx\nC7/7y/kPT3Z+tskiud74QROSbzwaQx" +
       "9w+zaYHlVpqafvjzv+1fLunb/1F8Pbnac3nRdP2UmP8qUe\nFJZiNdmv62XY" +
       "1UWu86kP3P9grrgMjPeuYjLvvP6oXg/Rvned2FoT3H7Yb5p2K922nz754HMn" +
       "mU83\nRnqmQb/Bp1q0F19sP+4eTo5097RSrSL36SYhOlZ679f+0vd+5498a9" +
       "wYjO48VbYKN7Z48X25edGm\n9Z/+/ne/8Nx3/uO3T0vSrmU76FfatX90PVp9" +
       "/wf9Leo3/9XXvnn74dz8wkNJvLHZZaTffd911NRq\nbfnv/6z4p77729/68Z" +
       "PfXDrOE3kziBfpjbnuJMU28IymkZ22n0PeefPigqHJC4WeXQjkBYMu0QuM\n" +
       "QxXl7UGvN+zB/clHeI2YemGTUsqrnPfzb3zvN//ur8sv3X5oY/jyh3Lzw30u" +
       "N4eT6bvJoWF46xzD\nSfqXgLe+/1PyD7eXSfPeB0OaiIrwP9c/sL76+/7Ef/" +
       "qIHPFEs32dUs1pmd98sNgvNwAatO1Pf3Cx\n28ZXr1fqR08/v376fPfKqG0b" +
       "bD967Ue/seRzyupiLlwQsizIJ9FhchmycLMAmRunH6vDqMELLc7o\ngN1Ih5" +
       "cbHaaaSigXMsGj9Jyezy56p7s/9nHkYIMXW5whp29E/kJDvpKFhpIj5jOVOk" +
       "v7Yw3utjhD\nK9yI9s2GViGwhUyr2oWioupCadZBvVBQlVZImsAfO/17Lc7o" +
       "sbjx9EmaIy7o+RLl6MfTfqbFGdof\nvzEtjqrojWjfa/BSizO0+o1oP9/QYs" +
       "Icp1VamH8Sg8NX3y+fUcG5kQqvnFTgeXSOn/hRjhNWj2FH\nGrzS4gx7eCP2" +
       "zzbsqChyRDNxgiMw9YJEm9U/T/9ug8+2OEOf3Yj+Uw+CrV38s6Rtenm1xRnS" +
       "+sbp\nhVzMscvlXoiiIKuPmXH/qk783BnyP3Qj8rvX8dWSk8Jifp542OC1Fm" +
       "eI/+iNiD/TEMsEJsj4Danb\nOX++xRnqb994zvS8oZZbBxP74uCx7vV6izPE" +
       "P/8J3euxpFCDL7Q4Q/pnbkT60imgL+d6uYU8bvNq\nud9ocYb7L9yYm75OZD" +
       "fy7Jb7iy3OcP/Vm8+bQz8B99cbvNniDPdfvxF3t+FezNm5sJqfZfxGg7da\n" +
       "nGH8mzdifP46jskFx53lbGuEL7U4w/n3blwjcMKMxlDuAqPQ+ZzgPoG10QZf" +
       "bnFGj39wIz3euq5V\niAueUBR01hZoN1fkRxu83eKMIv/kRoq81sY3Kp8KxL" +
       "ZmIhonaA0ze4wG7zT4SoszGvyzmzmeQJJK\ns3k2jv9otfzkts6tcxr8SIsz" +
       "GvybT6RBE/btpV/+OMavNWiH/uoZxl+9EeOzV4xi/7GEJ5wh/Hef\njHDwWM" +
       "LWru+cIfy1T0TIYWcJgasc9vUzhL91s2xy7UbXZdDHcn79ihc4w/nfbsT5XJ" +
       "usr14ynaV8\n5ypxfuMM5f+8ma+2e9NlnXmWcXxVBbx7hvF/34jxcy0jsVYJ" +
       "ed4kTXShUsRcbRKoSny0Ar93+ff/\nrvB7eeceFoeJF1jpmzMrslI9t8ykUa" +
       "Z5Gh7e791viW51blZq7wLj7evBllaaeXH09s6zT93u5Q+/\nb7l8mfyQci3L" +
       "rcvXN59+X4yLI+e9b//Gz/3rn/3yf7jducVcv7tpuzTBcOult374vX/edn32" +
       "Ztm0\nVVCJi9SwOD3L+dj0bM8yH+j4cG4L4o/UL7/3OgVlNHr9x6x0a4huD/" +
       "KQOiLczgQYCuElP1uJkWSx\n2mCquTgQD2TDU+ietSKJUCB6vDSaiExEzeHu" +
       "RBj5NUT2YkbyXRzBAhzzJQhVlCiEmAWeHneoKTm2\n7ke6hhfQAp6i8XTBbt" +
       "BNgmkbTliwOjg050wyKdXuxhYpZCjBoL09ANaotJECHmwCMaTC+sDJAsaR\n" +
       "xUZNyXoywCXviCo72sYVlYRVdOxFKAhu1cEepOxjaOZdlQvX+xWn1n6fUZZY" +
       "SOpbSxiTQrbrJ7I8\nRUqazSZUuFl5M4sofSjqTyHFhlbjwSA88CVPHti68j" +
       "RomBVCd6xzGCduMOM4gAoZkkUrnYo9PLHy\npUosPXKH7IMNeXCFtEpg3oNC" +
       "UoYB+qj4AzqYJ1A+G2Jsih3wbM2Nu8tZUSx8WNQkeywq/AFZxvPV\nQlniB3" +
       "OFWj1xUo9goEw3bsCG20RJiAPtussFcUx8wqOrus7VGWA7GoR7XnehQnC9k3" +
       "wLh3TIW01J\nbTmBGJff4ew822GWxqx6Bz6frn2Y9cfeYbGAIwsNh3u1Rzhb" +
       "x+eJJFH9KJxie7GLbSutv0XmHhRl\nBVtVHsj57H68FSXb0J1ZMhvwo7WXK3" +
       "lg0vJ0GRZbkthF1NKMMDR2lwfK18p+X9448YLqqiwP7zx2\nOxPGDLthpRlq" +
       "ry3D7+UsXSlQssJ8eMluttsaQo6Etkx4Oyb7DIjuq5hztDhWOVHGTYOIEZXo" +
       "8sQe\nHtuzdR9ESkOYjotqOBSM5EgXCcjI8p4/SOx4R1qQRy36NL3u5cOhRe" +
       "lRMPG1aVJvcQPe7wZiP4Ws\nSZcajfS0jLO5TR12vWEVTTm3zOteSq2F8Xq0" +
       "ZDW4XpL0qiega18QEoLfAb3EZCrzoAdsJoOml4O2\ni41FC+luhwMMrJww0I" +
       "xkNGI8IUEqnlyO6SLlh4GNlkuTHk/hUKUlkabHDB2DNAugwEGJh5Cd8144\n" +
       "07AU56rZXu6yi3rOAKpd8itgL2dhmDEGns1G60SHqJ3KUlhOWgO6WtteknDK" +
       "UAYsTTLXS3W0Wkis\ntZ7pFo/NZwNOCWZdS4kw0Kon4gTxBhES0cuscDnadF" +
       "a4HBY7YW7OzK1GJ6xBLrkaWaCVb8hGtIMG\nNgxHQLVO4D6vr3Yqs5C6O9hY" +
       "mn5FIGSyIpm52gSeB6HTfQ9dpYEz3R9qfEXPqh0dKL5aZgu+9g8s\nVB2CzQ" +
       "SJwoNQRKG6O0b6qIwP3VkE9dbEIDbTZUqLIytfAf1IJybO0bBWwYyN2G3jL1" +
       "LoAKaEDVKS\nZbTtcaXnYLnTjktgDBDTftGPQTYX2C4LuCjrWv5QYzzCQAYD" +
       "PKOEfrkHw81uy4q8k+TaYCOgFUGM\n3JHpmAVHePr+GC4qXOqvkcidABBPp3" +
       "WeQ92KjR1U8bPpVOURdbvbYLUmDtzVLA8GWcACQ29Qqqq+\niIZVtQ35vZwE" +
       "cDR3HMua+AdVsiGPPCydoubBTOou4xk2rAp1t0txIGXV1WC2mtlFoCMbsR6h" +
       "tJ1A\nACoQlqWLiO4eeQyZiijsmthKo0JozIvLmub83oZiiHnX4l1ZRuKJT0" +
       "aUpUeHoWZYwhrcVkrPCWlr\nM4d8GCfTxQjsj/Wt5FGMMxoEyfF4zIfQliQl" +
       "jdgjC3m6mVZitz8HQQsdFQAwFXXQ1iZECKipRTjh\nZl+HO/rQJH4oma22k9" +
       "4amFOyWo0st5pLO2OqTJVYJrwjvdyM2B3kY93p0ajXqV9jOW950gEeMjNp\n" +
       "U+Oe2TNmlJqZhG6vCWmfFyk7NHtiyZTlUse2YVWNy4o6LI6aV/bDCupz0KHb" +
       "dxR5CswwtBqsVLwu\nIYII2D05WQ5XVjROUHNRHvsWUWc8xBJ7CKrSoWSKpS" +
       "wgQDYbT5dLn/cPsylCr3G1q7PePKzICAkM\nDXb3vX7cT4/7AZHVNshX6fpg" +
       "aMBmnoMbg0oNsC/auoHn/XETTUuBCOgYXxl40j8weMyFXR2NSG7h\nZpK7cQ" +
       "mYK1Seg+S+ETL2KjG0RQGDUyk1pLlejEYjqpYxzj70nTFog3qZDcoFudqMNC" +
       "nCCoBfd1N7\nYs3XIq57PTeXQ9nZVZy+dAM3S9albUPJ0FyIccqMvFU05g5W" +
       "mvPJ1MpGDCxrK8bqCYgc+BGaY7zE\ndKNV7B680dY2J7iubjdAMBYmC53Cy7" +
       "4eKYCiwxwy2CseIwgj1+OMQAGHXKSN56XSi/K+JBdmvh2M\nEt0G+G463qgM" +
       "boRs1d/5Xi5tyNoxRgOSdgs42djbdVlW44FlW2Ll5po4g1SprUeYMQRmK1CM" +
       "LRze\nFYiYx/Fk2s1qYuvY/drOPKAAECkcgaCR8fVwg7uGhPusVcc7Zw9Pin" +
       "zPhUcyJ4e7vddjjKVzZFIB\nibflliojZ2BbWFdVt2YQEUG2KtWgPxvutvFo" +
       "GFJLtNwAez3fjfJymo8bu8kZRw7zNe0OwRGocCCz\nL21wbDNpQS2SXWZN50" +
       "rX2Y+2vGmza3RUTosMW0FYxtPWLqyhHF0CYjnc7vbHwZadUJNppIywoDeQ\n" +
       "YjbDtD5hizDNNjvHFKHSUSLtu6P5Os48A8lykOgPyqU8jOaTA7ZbiDhhQ00q" +
       "nYSh2SPZAKDEYAER\nR18hdqtpv8YOhM+6hI5qcpr3TDNeeF3JtKQKEI8A2s" +
       "TFduBTOJ248BH3K38cbjD86E5MP4pgXRZh\nKp3Cm+m2Z/ZxuV9RE2WOikcS" +
       "Xm9rbLyzJKArUbTdowiDxh2BmB96oLMtkFFQrSthhrhZU9sAOyiE\nKCTBOU" +
       "E+9lzKpKSQpCzcIRY1YWBqhEUJvoWAOOq6qjvDIpKfDnUexfMZRlDR9oB7lU" +
       "JPe/SOl2In\n2ksiitgzmHYRW43ttTamJ9KQE2HcDTEa2jhJKQzH+KSrTqnC" +
       "NZysYIBoVIyG7nRIFgtAHrJmj2IN\nehfwxHw0AB07HzL5YaIRQ5rjXDuxGA" +
       "vLD0LZlIkEuIVs2Zp3ATVQnKNv9g7H6ZwwY0kwy2b3nhNV\nb7BRgS2nylDU" +
       "2+Py0sNjZUalhzEHiVMYVOYhMDMZkOPhiOOJY9Dks2iM2I4IyJg9CjNiTXMi" +
       "Li4A\nopxGB4oWpv3KxJASG0WCwAwkVKug7QQdB6A0XlaOhUESSKnAtIRLVd" +
       "ytu07dny2TGkyYPWsPR8Vx\nwTMOixZ7ZRZDTSV4nKQTjSEiO0pBqbk6def7" +
       "nJ8k0mozHS4ScmdrIySc2YvRsO5W0AwVD85gZgvK\nPGEBdWGrco71CFtuVx" +
       "ZeKtvepKjS0sgymCoSeFr0NhIiF+AQF915LfSCoj+iNEymka60QKJtjdtb\n" +
       "oilHVhXDO3nNHNYjyUPFIjkCGjdeWkeQGe4nO1gxNcAJBkI0xoEBJi+WAHuk" +
       "mQkDrmJreES7lC9v\nuBAV10So7Ea4Tx/3CqExvoth0fhoSUgdKtBIc7MaXX" +
       "M7igqXc9GfS6oQx4wTsljMbo/zPhaprFd2\n0TAnNz45wQ7LPtFHtL5JrsAx" +
       "oIGbRTpYgBgysacIZjoTV6xMEZoB84KrOMPNIByk1dVYnpQKaYCl\n3NtB3U" +
       "YTja5Unmjqo2M+Ru3BWAaEZlUF1E7cySgF5t4YM2lgysPhtHEB1MeiDLFREY" +
       "Awu4IzqlGl\nxMA4ZsvutHTd4VC37bFM0Rmg1I3fuKTfPMps0KTkh7QIzqai" +
       "z2boyCczp1zU1FovipE12aWMTor+\nBItMGYswbad2p7hiNhsgfKy3EsyuSS" +
       "yUVr3ZRJF0YU0GCOjwdjImdGNwqIBonCOZhoJSlRxkxxy4\nDopIlTsdDcYS" +
       "FPTULi0fHHZEbjCRKFmPgHPOGDZPsBJ7kGucxdama8qQWycH3DcHatiUGrU7" +
       "ZQag\npPmlyqjQLHf2G361zJil1GW3BJHagkBTo9RbjnaFgsrxHNV4hkI3Hu" +
       "87hDFChT6Q8Y4qIn0wlpSB\n4vKMkJErGhGkmPYLAIxMxMXH3QBa99SaHvrj" +
       "3VyI5RDdzzYSBxH2pM8hHHvQtbWoIFjPQ5V121mb\n9wJFwjmxDqZkg6CCE6" +
       "+H72lPcbrjnj3UwaaIdUU/X01Tn/QdG+LZQtlzFIepBzJnoH0PdvY9omqq\n" +
       "jJBHbGl+sN2pt52uKacX7xhke8invXDclXpW5dS4Jsm4CsgFLUOxFE/wIsfw" +
       "sHl0b54CFCau5cOS\nMCRG8rwpPjNLiISqWIFYpNiuBuZUJAJyzZZBl8/54Q" +
       "LREiJK2OmxqbeISu61maDYTZgcT7NiapJ5\nE9M+tY7pPjKJpUW9rrUNDmfa" +
       "0eX5aRWGbXwZB6rrhXKW09akeRQa2eme39lwsl9NbMVSd4zIHCiD\nOaAFAT" +
       "mLY7TtoYCmsWPGznUt7ZHjYL6oGcPdzK1mXyvjrgMOUu3oNWG44Ko+NEAwui" +
       "lv/L1BMpTJ\n0I7g+6eEucBwZA031lgR+4HaRODSFZxNvRCGHgstZdBG5aIb" +
       "G+GhtuBVEpUFsj2CpiUy80ozmZmT\nm3msUjUNFUKpDhwxU4ZFb1FbSLzqBe" +
       "EyLseJMA5n4HLF+5KY1/tuU1giyjrY5XyNJNoyWw+IfRbw\nArWdJrQGUfue" +
       "qRfy8jiHRxPeXFaDTF/AGmwuo3BTB24TUGvqGKnDkRIy3V0VQv3+eh9vpAWQ" +
       "4pNm\nGnptCHLFrBC5P+gd9chKIaoIG2OCacz22GOMw7MkATa9plbZW9tjOK" +
       "CWw+TATrq4TyArTqrsccrT\niyib42kcckGelmuNmux2ibVzViM/QwRx6QyG" +
       "MA8BurePMHqg4FJYxamMMLuoyTADSOtauAhNaqtO\nBkmNlfwmkTO7n29mHG" +
       "l6/TFQ6mPQIFXYo+LUlamtLeaylmysxMNWgcBmgnBMheFy1pvve0UX2gzX\n" +
       "WmyWNgIU0Lwpxod7YK5PViuQhHviUADW/aZmAovCMPlqZ65dCbKDCYkh8L6/" +
       "7svNQ8PqqA+ZYLsa\nL7sLkGpKNjzbQ3SJoujvb18T3bvZvwxPL8seHMPceX" +
       "bb9+nTK6fDR4yQd57Rt1me6kaed559cNDz\nNOZDR84+8xHHFO+/+tJ3/vQ7" +
       "f/7fPnrSrNMe6fnCx52uPB3n+db6vz//0/ovfbPt2nZEGu48Tt4N\nrNIK3m" +
       "d9dBD+dJj0+oTXX75zz3ySG7/6Yf688/TV+9n2mNSrHzqce3mE1PjSr/zE13" +
       "6Q3P0Xt09n\nwq6Ped7hOs80D4PBw+fFHmrfSVLL9k5a37k8PZa0X7e+lnfu" +
       "ffgwYjOvB+1WxVtfvZQGGrtfS7e/\nv5F8xNvMy+Nuh/8PQ3oF4mQsAAA=");
}
