package javacard.framework;

import javacard.framework.CardRuntimeException;

public class APDUException extends CardRuntimeException {
    static int __JIF_SIG_OF_JAVA_CLASS$20030619 = 0;
    
    public APDUException javacard$framework$APDUException$() {
        this.jif$init();
        { super.javacard$framework$CardRuntimeException$(); }
        return this;
    }
    
    public APDUException javacard$framework$APDUException$(final short v0) {
        this.jif$init();
        { super.javacard$framework$CardRuntimeException$(); }
        return this;
    }
    
    final public static short ILLEGAL_USE = 0;
    final public static short BUFFER_BOUNDS = 0;
    final public static short BAD_LENGTH = 0;
    final public static short IO_ERROR = 0;
    final public static short NO_T0_GETRESPONSE = 0;
    final public static short T1_IFD_ABORT = 0;
    final public static short NO_T0_REISSUE = 0;
    
    native public static void throwIt(final short v1) throws APDUException;
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1185987218000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAL1ae5AUxRnvXe4Jx+OOAw7kuOUlIHAPQDReknLvBXssd8fe" +
       "HdFTHGdne4+B2Zlx\nZvbuQGMkKqCWJlbEaCpRJD5QiYpaiv5hSLSMiV5Kse" +
       "KjjHoGY6xEUxE0asWk8nX3zGzPzN65+Sd/\ndG9Pz/d19+979dc9e+RjVGwa" +
       "qHaHnK63dunYrO+U0z2iYeJUj6bs6oMuQbrnk4r/DP5qqhhGJXFU\nLmat7Z" +
       "ohW7ssNCO+QxwSG7KWrDTEZdNqjqMKOaMrOINVCxvmZehKFIqjqbJqWqIq4b" +
       "iYxIqF5sRh\nugY6XYNCuhroC+CewSgtWbRwqsPQMhZaGNdhIYOKZjXgEatB" +
       "Fw0xY/P2tCqiaQJbCe11piszs0lK\nQJ9HDBRxRrAhMnyUmQFsOtQ4++jFT1" +
       "ROQtMH0HRZ7bVES5ZaNQAxYg2gigzOJAFONJXCqQFUqWKc\n6sWGLCrybiDU" +
       "1AFUZcqDqmhlDWwmsKkpQ4Swyszq2KBzOp0gIEkDjEZWsjRXQCVpGSsp56k4" +
       "rYiD\npoVm55AzvB2kH+BOlol006KEHZainbKaslCdn8PFuGQTEABraQaD9t" +
       "ypilQROlAV06MiqoMNvZYh\nq4NAWqxlYRYLzRt3UCAq00VppziIBQvV+Ol6" +
       "2CugKqeCICwWmuUnoyOBlub5tMTpp7uk4t/X93we\nCdM1p7CkkPWXAdMCH1" +
       "MCp7GBwdQY4xfZ+ltiF2bnhxEC4lk+YkYTXfpkf/zDX9YxmjPy0HQnd2DJ\n" +
       "EqSv1s+vPRF9v3wStTJdM2WifA9y6go99pvmER18a7Y7InlZ77w8nnj+wqse" +
       "wH8Dp4qhEklTshk1\nhsqxmmq126XQjssqjqEiBX4AeVpWMEFeCm1dtLbT9o" +
       "iOECqFMg/KVFIsVBntaetvH5GwTqaqB3ez\n0Cow0dWmITUQXUuikWpIg9Pg" +
       "Yc3Y2RAgHyFDzxgOhQDAfL/7KGB5GzUlhQ1Buu/k765o33Td/rBr\nTvaiLB" +
       "RxJqp3J6r3TIRCITrBHK+EiMhTJJx89GjzjJtWm0+E0aQBVC5nMllLTCogiA" +
       "pRUbRhnBIs\nalKVnPk6IaEiCdYHhiwoMBALBDoaMtAiv5XlvDFmR6nL13eh" +
       "Awvaf0IMgiiwmozOlgbq2MnWVrGi\nd1vnpfsXTSJEw0Ug9jCQLvLE0TxjC9" +
       "Lte8deebnsaHUYFQ9AvDPbcFrMKlZPa4uWVSFoVLtdCQzx\nRKWhMY6msLAh" +
       "gus7zluqS5SHPIaBwsjR0y6w5iVfj1aQembO6rrnn2c8yBzAL6AeQ5NwCgJb" +
       "jkFo\nXLuw6+CaLwEC+DYszIJlkVCxwO/bHndstn3XQosCocI/SbMTBgkSmG" +
       "VKWjMyotLnhnWIgtZ2QxvO\n9VCTnUbblaCOMihzoEwnhXTOJFU1M2xSLSGq" +
       "9YGlEfZ0bN/GD15cvi3MB+Pp3FbXiy3m2pU5y+gz\nMIb+t2/r+dGBj/ddRM" +
       "2C2UXIgv0pm1RkaYQuriYEZjgzT5ipr6m+5dYVP33dsbuZudGjhiHuImY3\n" +
       "sudE7e2/EX8GIQjCginvxtT9EZ0JOROQup62G7iX4Gu5+XOGGjVN0B244wVf" +
       "rbv8X98702Dz+7lh\nQWfkmOi2DRupbFB7E6Tj1VcfuO6r6RvCxBQng02kIX" +
       "+QJUgS5gd2+1b3Lah5CtnMBh3i2gBxLPea\n7BJz/Guw5x+d9vqJtoe/v5DO" +
       "PyWFTcmQaZCx42WJpXWCOMkeSWcwRNVUIMtgqUcffdk+ohvNzIxI\ntZRqYT" +
       "Gd0CHPQc6xCNLZV3346WN/eGIZ86A6L0eAeuFDtf9YcuSSpY6eF/ghJbAIsZ" +
       "VhhsGXnLz/\nk2vL7qXIirVh6ml1nJx02LAlWRdh43FaJCcy6CgESBQWVRPQ" +
       "nT1888GsqNV+KZHVcNC9wcydor5P\n091ZBGnje79+99of17zIA/cxcNRNs2" +
       "pqIqfwZOpYrkIW+xTiMoyjFFjZmV4J82viBf3GnnnvrFz1\ngxfY6vyKzMfx" +
       "8wc/v3v3snsHcy7QZk9KfjbmU9Z3IBXOKeuas/a/9enja+dzyqIaALzDlJDp" +
       "g9Qt\nLpyl+eTWolmWluGkt+aFxjnRw5uPOopqd/lXeJH5OHl8TRWHnvnzA/" +
       "cfdMaIUVzdHMYttD5Ht+F/\ni9bn6+xlt84TeZ82209tuiOs4FOdJzrXQZlB" +
       "Sr7oLJJqed54FmJh1fQEA+plOMVSulemrN0fOTtd\nTbVQTvUEOb9lb5RlhM" +
       "N5nkynnKoTOc7z6zZqDNrhZdtbl7y098Xal+muXe5u0XEUlmQStfwpspbi\n" +
       "t7JcXgSxMatDLsxv3OEhmURJ3xBbRXeLZuZ/niu82VAW5BGeBSqBQTKaoW+X" +
       "pQjFENHSEbZ3RkRj\nMEsOZpGhRtLLnUMiy5NkPTgVEZPaEI4kd0UuP+u8yH" +
       "dXuMbpGlerqKqaFYhpf+3++/HdOn7BMaxv\nU52Bd4eHGplFkWqn16pYV87N" +
       "dnosJ9Czmevp5tpb8vRA1upJxeKaJCq5DKb6uy3n3Pc2Psq2eIVP\nmfwnCh" +
       "/n87cOrrvz4YeLWUzxp8ac0gTp3NeGKkseuTMTRqWQ6VFxw9F2q6hkSaYwAM" +
       "c4s9XuhDOy\n5733SMbOH83c0Uf2pUe8gRWRpeRMexqTSwjppHEV5TiT1ivc" +
       "/KQ4LauiQsk1MygCCCUZOLMM2Yeq\nmxfc/cFjJxPVYe7kuTiY0XE87PTJed" +
       "rCiWag1M+tXHjkysQ7SSbnKu8JoV3NZv6y61m87Js3vpfn\n4FFsbteYd+8g" +
       "1d4C0yJSnx3Me1zrTQatN8lZbzJgvcmA9SY5600GrNfpIVW/vWhyZvFbWQe5" +
       "LXDs\nLJO8/LNn75gcyW1ZtXTlZQEf8LAJUvjw2L4VNdPfhCA5gKZtF82YCi" +
       "ogdxrY+Dqn8A21+5n+O74Y\ntd6husgdCAj3Iqr1Kz2BvwnKNFK42GXb5115" +
       "7bPEpBcyEOAigtAZ6xB6YxuE7g6hM7o1KrTGo729\nS9Y0Nq5tXN/0DcqJdU" +
       "5th4JqO8Sp4VBADZ6ezf8j/TX21PssNAkyW7qfUcs6TLvvdAUxC8pKKKRd\n" +
       "yQsi5B4siPPX0/wXG1V/Onj353v2nRsmiX/xEAkSoJcZObquLLmj2nvkQO2U" +
       "W8ZuoNZA7JcM+mRQ\nqJNI+2pSrSTVPSDaKbF4vH1DNC7097YHpXgsKMVjnF" +
       "SOBaRyLCDFwuipx+bEdjyP2FZDqSLFKzbS\neMrB/FJBmKe29Hd0tCeElu7+" +
       "rrbeIOrRIOpRDsVoAMVoAHVh9D7Ur+ZBfRaUmaRMgPrdglBPbom2\nCfH2rg" +
       "19G4OQx4KQxzgIYwEIYwHIhdH7IH+QB/JyKNWkTAD5VEGQy2LdQnsi0Z0IAj" +
       "4dBHyaA3A6\nAOB0AHBh9D7AX+YB3GT/zhofcKi4IMCVXd1CX6Owob0v0d7b" +
       "092Vx6dDJQHk0OWu22lvGadnc+H0\nXuShijzIV9l57ewJkNcUhLyir0mIdb" +
       "QJ0ZbuRF8Q9Nwg6LkciLkBEHMDoAuj94GuGyeQkTuqOROA\nXllYIGPqTrTH" +
       "env786h6VRD1Kg7FqgCKVQHUhdH7UK+h2799jqP+yhKw2tytUu149/40D9x3" +
       "wScV\ne8XntjkHi/0WKrc0fbWCh7BiDzsUHGQz/czhZCh3lVSliuLn1vhzpF" +
       "Dg05eXT5Def+TxxXvK//jo\n/+W2tm5CEIJkPSmcen39m8vpsdZzpmSD9XkS" +
       "/4WuqRG/WgSlhhTO1KiaiJZieWwMsi5VJCk5Z2dM\n3uMcx3mbG3TnXmynOf" +
       "65LZQo7KzaRHrZV6sIvfGNWeMfV8nYGbqU0AZSdXIYSbVpQgTBTLtf3alq\n" +
       "wyo796x5bfSlV9tGHnJMEY4yE0qETHghAC21l02fEeJY8pw28tww2YuwbyJO" +
       "Hl33e/W2/U85qziP\n4WRmTb+BhgRPFySiQ03LcqEgEQwFidwxxmlvHKdnM9" +
       "fTzbW3jNNzBeth6X3oMtK1h9wKNNFAwYyF\nkZC6l1R9VHL9pCJHiBB2Occ5" +
       "yXkskFRVVDL9VPd03IvpOy43LxrS5FShJz9XlpzIOjmRdQZE1hkQ\nWScnss" +
       "6AyDq56NlPwrnnOxm5JK4JfMNm312lRScuXf6sXvnbMCriLgjK46gsnVUU/l" +
       "6Aa5foBk7L\nVErl7JZAp3K63kJVwa92EHLdNjWw6xj1jZBXOdTk+SYmpVkW" +
       "Wpbn018rPCayqiVnsIuMO+TWTnh5\nfPtFN+tqY1Qe59tELqSzK/U53qCeZf" +
       "8UEKSP9Es2vJV49wH7RtiVKR6x6ul/CJzI63Jc8IuLIiM3\n9P2QXehKirh7" +
       "N5msDAI6C1Usvo/wdxr+0Zyx5LHX0tdf/f50z1U7s9UZOUEsGH8c0t46tfmN" +
       "TU8/\nfdi/lyFOlhx8yuNsIeuWf1b6xeip8wuQ4n8BEK44thkiAAA=");
    
    public APDUException() { super(); }
    
    public void jif$invokeDefConstructor() {
        this.javacard$framework$APDUException$();
    }
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1185987218000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAALV6bazkaHZWdc9Mz0zNzO5078zuaLMz2zPbSXpwtstll13l" +
       "TECyXXaVXXa5/FEu\nl8Poxl9lu8rfX+WqDRERUjYhgoRkly/BElAQUbI/gE" +
       "jJPxJpV0QJ8Gd/EPGDkC8lSJAfgCBBAoJd\nt2/3vbd7egcQVzq+b9nnfc95" +
       "z/uc8x6/x1//o84Leda5m8TBwQ3i4kFxSJz8wcLIcscmAyPPlebG\nmdX/B+" +
       "Cn/8mf/6Xbz3U+qXc+6UdyYRS+RcZR4dSF3nk1dELTyXLcth1b79yOHMeWnc" +
       "w3Av/YMMaR\n3rmT+25kFGXm5JKTx0HVMt7Jy8TJTjIvbnKdV604youstIo4" +
       "y4vO69zWqIxeWfhBj/Pz4gOuc2vj\nO4Gdp50f6tzgOi9sAsNtGD/NXcyidx" +
       "qxR7f3G/au36iZbQzLuejy/M6P7KLz+es9Hs343qxhaLq+\nGDqFFz8S9Xxk" +
       "NDc6d85VCozI7clF5kduw/pCXDZSis5nP3LQhumlxLB2huucFZ23rvMtzh81" +
       "XC+f\nzNJ2KTpvXmc7jVRnnc9eW7NLqyXcevV//uXFH9+9edLZdqyg1f+Fpt" +
       "M71zpJzsbJnMhyzjv+Sfng\nK8y6/NzNTqdhfvMa8zkP/p2/vOT+/a98/pzn" +
       "O57CI5hbxyrOrP+Bfu7tb+G///JzrRovJXHut1C4\nMvPTqi4ePvmgThosfv" +
       "rRiO3DBxcPf1X65+u/+PPOf7jZucV0bllxUIYR03nZiWzyYfvFps35kcN0\n" +
       "ng+af83MN37gtDN/vmknRuGd2nXS6XRebOizDb3WUtG5jS/GS6q2nKQV9WDr" +
       "b4rO9zSA/WKeWb12\nrS0js3ubrFn9fZztek+w1+3Qr+1v3Ggm8LnrzhQ0yJ" +
       "vGge1kZ9Y/+r3f+EFq9mM/evMRnB4qVXTu\nXgh68EjQgyuCOjdunAR85qqF" +
       "WpPbrWf8x3/6wet/9Yv5L93sPKd3XvbDsCwMM2gM8aoRBPHesc+K\nE6RuX4" +
       "LvCTUN5F41G/Q1QD4LmoFOaG/sVGWd966j7LFvMk3LaKDzJXTe+eo71N9uAd" +
       "Eu4Bvt6Oeq\nNcuxO9ft1fflD9kf+NH3nmuZ9s83Zm9ncu/bj35mLT715vwf" +
       "/rfv+IVzwF1XaJHFlmM3YeVxhzMQ\nfnf+M9B/v9l5ofGlJpoURoOHxjXfue" +
       "5LV+D/wUNfKTrvPeGa14V8cBF2WlPd5DqvbOIsNIJ2mItY\n0S28LN4/vnOC" +
       "yCun9if+9Pzvfz2kP21CChmHSQPX7O7EaXQ1CsdOzkHVXu62Zr028VN0+y/M" +
       "l6d/\n8C/uf3jzciD85KWIKTvFuVvdfrwqSuY4zf1/+zcXP/3VP/ry95+W5O" +
       "GaFJ1bSWkGvlWfFH3zRgOB\nTz3FxR+89cZX/vr7f+c3L9b8U49Hx7PMOLRL" +
       "Xv/wt97+W79m/N3G/RuXzP2jc3K9zklS50JAewVO\n7e+59PDh0xaB192Jbm" +
       "P/xTqE5pf+6ze+1r17rkfb57OnEV7Jn4x1VzqeWcd/tvzan/yr4rdOpnuM\n" +
       "knaMd+onxarGJUiO/nV1+9Y//nvhzc6Leuf1035lRIVqBGVrWL3ZcXLy4U2u" +
       "89qV51d3j/NQ+Rh5\nn7uOvEtir2PucfRo2i13237xMswaQ7zUUL+htv2J9u" +
       "br7eV2faOTtI3RifELp+t3PcZAftre6yYm\nnZ2xDH0mM5MzgT5jcRU/Izlc" +
       "lu9BIAiDaB97ip0XmR82Ibt6uKf8tXd+9g9+8fekN25e2ni/8KSD\nXepzvv" +
       "meJtJN6kbCu8+ScOL+JvDu139I+i3zPEbcuRogqagM//DwDee7v++v/M5T4u" +
       "5zTXpw8rST\nFQaPTPdmQ0BDt1u6bLobj9ypXcMHTJNduE5253d/5mf/+Ie/" +
       "PLrZwv2Fql3rRpXXH/PNyzZH+pGv\nf/XtV77y2z9+QmyL9XZQ6slleK5oVt" +
       "uPjNPWfb+9fF+zHq8wHEdNcO5sKZ/3+XPJuavgDXvuxdlH\nzuSLDd1p6epM" +
       "2sbkQg3xKWq0be6KDq8RS5qmpDNCWM7Hcnt3/lFC/0xDn2rpGUJXH0tol8DH" +
       "Zxw1\nnyjTZ0q839AbLT1D4ocfS+JLjHBGSZIgPVNe/+H/N58hz/pY8m7PhT" +
       "MFPJtQikTJC2EuU88U3EbL\nT7f0DMH+xxL8qtI/Y+jxGU4IkvJMmS2GPtPS" +
       "M2TGHw9D55OVKEaWl09MtL2824zcYBp+AD4A29/l\nxxr3M9vAunexlarNG0" +
       "mTNt1r8rNTtzvFZXc8T9yfIrXx7k88ZuPiJrv/8d//yX/5E1/4d41rsxeu\n" +
       "3XJPm2j5xnvabyzaHz/YXvZN/t+qIMdlZjmckRd8bPvN64r9SItLHvt8ED9V" +
       "g+L2cjrIGfzij+sb\nDoIvaymqNGfA1oAg4PvhrhSWATPFF+JYcnYRVxFant" +
       "ujjTO1aWU6sSNnABCQHtRdvTJLccLvZim5\nYgOTMshEYseI6K8Tw68QT+Zk" +
       "3leRWe7MtttpPFmjNbWsKdDIV7tRpMHHyXFxnKMIINu9rj3BFsee\n3ccAbI" +
       "jZFuYA0lad7I10akyjGQrbZbTOBGAJHiF/7bDLLWrmaMyXoplFu0HWGy+QNP" +
       "W8CavRyy4X\nGsVQj73VMM/npACI9V6eDGerbKxQuj1Ptyk/Eww+E5i5StZV" +
       "qDvejGaa2yabrlImHZj+umZSGskl\nr1u6a1Rbz8mySbxIgHT2slusTGmf5g" +
       "uR93RjMrc9Zi3M9K3mUkZB0HuwXvcWUEGmviGyJun0+4mf\nH3MwmHVFFpuO" +
       "CamWMtzjo8MyFOlcKMQBAGxppS8JYsFPwamkD02VkhHdmIt4vXYh13ePAovT" +
       "wpzV\nyFSkl+lqZnXRfDXhyOxg+uNlH6eXupWO09ALxqt9mM92iTiQ94f8mE" +
       "Iz4igkoMtQu/GW0lf5VtJE\nUk0mcp4gaGO9tT/uJrEaIgh+rAhoNwUIIYgD" +
       "EERn1FRvEhhzZuQBaUejBV1ORIXCicwQjTHWbJx+\nIEpCgKsgyvtpzM8rfe" +
       "1108EcX6V1sJbW3FEq4CWJpyCoJsnRZwixUgEhQCGydGepQzLkfhWWyyg+\n" +
       "CERQmkjBK0kyLHeDoqdh8N7pkjbfT4bkbrdYabjNk9M+TybDCbG3xfWg3uhA" +
       "UPg0ZEZeTZGDYAes\nd2tF2yS7Te841rB1HW4XB3AqRjY0ZrtUKlf9HKgWEo" +
       "1V8F4uFNbmoZW/wbED6sYYllQhJfVHxnA9\nZKJAHw73oyjaAs1yO/vpaJwM" +
       "Uo/aBUru7fpdL0/rMEz7EKqJ2zxvAET5hDbAHTVZ8RTtkGHfLjhT\nwWJfoM" +
       "iU5t3eTKWZXCWatNApqiky2SupkRKwc+yCZLwH7VXIKEtRW5b+bpUwLrZw1x" +
       "a8hiTcnR7o\n8bF2BU8c4xuuN5xNCGRyXAae2CfKsrcbokgMw4rdy4isq1SG" +
       "zzU4Y9MEZtEMVhiJZJSMmM4Ayuc9\nhWXrETbZHrdssQpBoHFKkVBJJOKDgF" +
       "PI2PXxRFqakhcRTN41gpkaLXYoY1A+aa+nnr+PeQLniHFs\n8AXe+LoWVGM6" +
       "lNCI68OOh+8rYwMyvOv7+zA+CoFrphAfrdRs4nftfhUlm1xTZJbag0sX25Ii" +
       "V3EU\nqNRbEuMKZ2Q7jhnlxnS5pkUMr8YL06IzfhboC2NQrlSZjlWusEnxWH" +
       "el2crj12iYc7jnlvnwGJSp\njMjTBWMQ+wbm4AHdI7662fYNscnqBTTLogiy" +
       "RgfiiHMo7ojIfE+6rLnd0XFX48o9CpAGt6dIYLzO\njwwb7Jr4sBd65jSy8y" +
       "KCNTFuUnCL6ckmrxDuTg4n6my15Q9xwUVetGLcQofEuhK6mEoq0dI0A4MU\n" +
       "eN87xtQ+8jRFYOlln4fqJjZOUmw9CaiNDprz3mTcR6zKh3kCWCQwbWr+AQ6h" +
       "ZIkcAPfY5RkTKKBe\nBtgTYtuzbYmHSGipMW4FJmFf2hlrscz8NaVv3aOC+E" +
       "mGhgBir9UFDNu5WeqlPdl6/rRkwjXczUub\nGjpQj9JGE0bckq4fVXWhYJQO" +
       "skITgcoEhSZDXxtMSgTQhMlkq85BAhoM9uomM6uRho2GIDQ+AsPA\n64qrzS" +
       "4UfGgslYlJE0MKVbZ91dqUjalRqSJrQoxcENoxGiCyS1dGXBsC+ibMGR5CFh" +
       "FPeLAPuUTN\nLRyjOyTYY29S7pEasLEqZYvY6VXIWFgcVrRihaKhk/UAWrGJ" +
       "tmqMunPklbWX5uqS4Qs3XVqbjb0D\nYq+aH5ma6Ra6lK6ViQ2S04VooTU553" +
       "QVhgfoat5zJow+QnGUAx3cKelxscHWVinLyRp16J7rsSbO\n5LrqeflEi7hj" +
       "r7uDKm6YaoyfqR4aBv2IrUGIw4OVZHsDmDZY0jqgpEvJhLhSpYUYKf3RaDTJ" +
       "07kK\nzPSpas1JbG8d7DhDFl0Q6+vEJNo6w2azw+JNf3hk8J5VW3NpnkNJs/" +
       "9s9rqQrLMdswJqxefjw5am\nt3qoDtgRVPnEBp5EUVRl9LHfdevNGq0OsyO/" +
       "qUd7q1fBFZxH+dQ6DEV9h802WzNcYjrMEJowc0oj\n7xk9zIm2BmAfDylj4N" +
       "xxHLDjxMXEosslhwBwlFUchKugnOwKwKDrbSTtkXIhxElq9wLNYaeIMA1G\n" +
       "irSaRlV0bDTf2LzBLNWjPeXXRTFGpgVA97o+ZkYoUAfFaKA4+giCQKwofSEf" +
       "0ILNHjNN1ANCzoYx\nx7KpYyMDOmS9/kakcCAJBF6Vy8AJszm4EZTC7iqmKi" +
       "rVkhJMLDARKfD4ORLtDlE0ixXBGh7Ro56O\n55mn24UZDA8gNtKMAAhLzUFK" +
       "UKOWQSjKxWaf5Inpd4sha2muXPNGMebyuoIFyguXEgvXhClpDqeX\nei/yyx" +
       "Gk4iuEmDiEnBKiMjPiFaAl4pam5lOZMnVY2knbLk/lgp5MPKnguGjJ+wdkvl" +
       "sorko14Ypi\nBjsbXJYLoBwdprZW8mYyaVLIdJYa9NpLNgAMAL2pLURDgjfq" +
       "qrtEIMIeONNJEtC7VRr10WStjoZz\nO4pzFiOPoVMlSJGYo0rC+2XC1s6swV" +
       "6KjGcmWh7gCF5Y0CJPIYdRF91ws49IrxeNhpaQZdVxsHa4\n1fJYJyPDAl0l" +
       "gefOZLbLnVLhFSldiahK13uMhlLU28nGeo/z1iDHtNIbC4cuMoRhmTeF6Qi2" +
       "wOWm\nCU3OyJVWUuJIfJO2KvJ+myRTSkUUX+n7ldWbiQPOKH0x3/X5g0uS5F" +
       "IXOJ6H1k7aDeuN1bPoLVsv\n1LXTpJyKv25WaTRcKKxjZ6S/Mtw+DxTadLs7" +
       "5OJQls1oVo7YWIXneoUe0H44GrI5XCWbqDug6dws\nnLUNjNy+PSDBAytHNc" +
       "w7/WOmiEYxHwW6eWTdygpxTF4jKAhOsvkmYdRVr1p5B72izZXoIJw2zrsc\n" +
       "K4x63DwaIq51WPX1QlMCXaQ2Iw5nl9V2D3EDdW4vNh6JI+5ML+gRtCb92LXr" +
       "bA2M02iEQ30AiQBh\nOFh3Cxv1yty1SXwLM2nWnx0hotpHszk9G0ATzUT6fW" +
       "RoLqiEsA6UgPtugetoTaDruqSGLurxw7g/\ny5RJPISwroytwXmKFNq8B46t" +
       "lLWXSOEN2FQYyclAbd5jddQ5bkbbnqJB/UWT9+K7w2qYbpZWjipc\nVdlNpk" +
       "+OktlsJtndg5j7CDHI/cVCA3t7bdJXe0K0hRG4giIpD32tV1P4To5ZSxfMtO" +
       "S4cAtF1U4U\noOVqpJfxXMcbJ+KBUBK7KTtnACiRM1lRF/LYmJn0oJr2x3Ny" +
       "CGLD9TTR3HzGq9uIlgXCkA4cOab3\npZ/UgEnZ28MCovVxKnP07GjKXYfPiB" +
       "7NEuHMgbCpDRakQwXlEMgy02GETGKERBrnaozzDU1VDxsP\nlxmgExvJWIaG" +
       "xLuLzHYDYmHGIdQlN1Moc/vYZCCI9WAm1keXWe+phqaMZ0+HzBQQiR57mM1X" +
       "OwUf\nIyo1EQ8QZ4tR7oM6yODbgU1MDwYO42gXFwgQnxKtRFwD1gQ8UXpHL9" +
       "5YM3/A8KSq2X1SQ4V9bIIV\naA9NEIPUGrXHrDjdgcKqhKCgmhh2ZAFTsKuV" +
       "sudvj4yKBcjQ2bO7ubX0uIOfgSFjmyIL6mYp0SMR\nm+9dlNtZPrcjqCk/jv" +
       "FyizU78+TgiDulTJsNG+9qQbBmJotUyZSpE1XDEeqhqjTuz9whnbrkTBWn\n" +
       "y3a6yxngQUMM26YL4ODN9lBxKJZlf4D1BuAYq5ts2FK7zkiLiu1u6vfA1Syz" +
       "wI25Ir0h4Y+P+XI6\nEY896+jppAcHqhz4JRf1K++Y0GMXRBxNQcbOBlDqWq" +
       "tmvd427vaAFVSECEkx7G4hh5YTwVg4qpLc\n1o9JKI8xbSf3BqsylSa9lSsH" +
       "nqcI/Zlv+KzuO6s936BUZckdokM234VL3qrh0JzASqSFh0jYoAin\ni/Fwdj" +
       "SkaaaraM5Um8l85fAbdRStJ2a6BHFdtjVmLZtqIroKoXDFBjaCtLs/xEMMrR" +
       "FzIwcqVkym\nEctT68GBAlNKmboeTkL9AIQ2lMOuR8keGhX7PbQu9+aBbXY/" +
       "GHZ6K6i3HCHp0V90ByspVEyA8Fxp\nQR9kXwRhzkoplxL3tG/v6zoMqunMjn" +
       "hsoxzNFbydz4+EU3ioBsd8Met72H42n9P4fn2guzudRIO+\nhKlTDktIduoT" +
       "BCRYFnLQdvmOllR1zGHqwgZhpkqEwwDm6kxGaNljj5gWJEdG2IaSLepU39uJ" +
       "3ZVs\nRXmO4odxiqDzYLFv8l+hDhF2NmA3/DyE+1AgyVapbdBcqyKTJzOfc7" +
       "ezAermkbpc9gIUN5BNTOyG\nXFelsmDI6ngCNy/kO1bdGxhETTl7vl3t0Xrb" +
       "3+pNkmErO0Beh4m6W60SMwL7o2xBGofUV6OcKXkB\nUFZK5CHdzaKg50CRrv" +
       "tN7MUKikvl46y3ROCUdPTNaEnN5AVG5VDFqgNsPx1Kha/OJLRGy6BHskcG\n" +
       "hVlrxJQc4/NwF1tAota8xPuZN5wjYT7GGZTsL/Mq7u2b0AyA+qFGuKkGFvam" +
       "t0HAY385zLFmR1pS\n+WQ6ssBigBabcK4sR73uxvZ7wYEWAq8eHcp5zjjlat" +
       "M30drxk9G+FAfRiKBmg0Hh7Xwcx/9se77y\nlx4e09w+nRQ9qvdu/U374Hg6" +
       "jTkd7nznwxJEewUulRY67Yn02x9VfD2dRn9Z+0+v/ojxzQ/bM962\nI1F0Xi" +
       "7i5IuBUznB48rG9UH4U6354rj/79+6Yz/Pjd66Xtpo6/Wff2bPM6v45bP//J" +
       "vov7l/83qd\noJs5RZlFypVqwdtXqgXtAd8nW7p0yHeySnv5yUuW+YjSzTMf" +
       "Fp13L6qc9x5VOe9dqXLee3wg9hNX\nFPt8Q6+39DTF/sZHK3bjvKxxOmT8/6" +
       "Ndew77XkNvtfQ07b721PP9W5HRFjEuHWD+X+p/ieO1ZhIv\nniqPTPHEcWMV" +
       "+/Y11dtC+He1nc8rPz91AvLYsQIlZhtTUHVxZj1ojXL3vnVRoXQvKpTvfy88" +
       "HHzv\n3bR5WfHTMi6c++fFw7utoLuNS91r3ljjndPsNZcqu/ffv/ulwvPzB9" +
       "/W1vff/+AvvH+pDPoL/8/o\ne+ujlGpZf+4poLv92DZn/4e26cPwVdtkftU8" +
       "uWwcv2iNcff7P5TvXpnoLz61LPfiwxGePclvY4GX\nLiSfZtwexV+xeVvMfe" +
       "uJr4HOv1mx3vvWD9z/RnL712+eSo4X35Xc4jovbcoguFyOvNS+lWTOxj/N\n" +
       "7dZ5cfJ8or9adO48+cVDEykftU/a/8o59zdazR9yt7+/mVwc6X/3Uz6bIJuf" +
       "UhkVfug8mln9vwEg\nmcwm7CQAAA==");
}
