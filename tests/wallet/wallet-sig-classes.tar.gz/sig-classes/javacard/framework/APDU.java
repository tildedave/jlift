package javacard.framework;

import javacard.framework.APDU;
import javacard.framework.APDUException;
import java.lang.SecurityException;
import java.lang.Object;

final public class APDU extends Object {
    static int __JIF_SIG_OF_JAVA_CLASS$20030619 = 0;
    
    public APDU javacard$framework$APDU$() {
        this.jif$init();
        {  }
        return this;
    }
    
    final public static byte STATE_INITIAL = 0;
    final public static byte STATE_PARTIAL_INCOMING = 0;
    final public static byte STATE_FULL_INCOMING = 0;
    final public static byte STATE_OUTGOING = 0;
    final public static byte STATE_OUTGOING_LENGTH_KNOWN = 0;
    final public static byte STATE_PARTIAL_OUTGOING = 0;
    final public static byte STATE_FULL_OUTGOING = 0;
    final public static byte STATE_ERROR_NO_T0_GETRESPONSE = 0;
    final public static byte STATE_ERROR_T1_IFD_ABORT = 0;
    final public static byte STATE_ERROR_IO = 0;
    final public static byte STATE_ERROR_NO_T0_REISSUE = 0;
    final public static byte PROTOCOL_MEDIA_MASK = 0;
    final public static byte PROTOCOL_TYPE_MASK = 0;
    final public static byte PROTOCOL_T0 = 0;
    final public static byte PROTOCOL_T1 = 0;
    final public static byte PROTOCOL_MEDIA_DEFAULT = 0;
    final public static byte PROTOCOL_MEDIA_CONTACTLESS_TYPE_A = 0;
    final public static byte PROTOCOL_MEDIA_CONTACTLESS_TYPE_B = 0;
    final public static byte PROTOCOL_MEDIA_USB = 0;
    
    native public static byte getProtocol();
    
    native byte getLogicalChannel();
    
    native boolean getNoChainingFlag();
    
    native public byte[] getBuffer();
    
    native public static short getInBlockSize();
    
    native public static short getOutBlockSize();
    
    native public byte getNAD();
    
    native public short setOutgoing() throws APDUException;
    
    native public short setOutgoingNoChaining() throws APDUException;
    
    native public void setOutgoingLength(final short v0) throws APDUException;
    
    native public short receiveBytes(final short v1) throws APDUException;
    
    native public short setIncomingAndReceive() throws APDUException;
    
    native public void sendBytes(final short v2, final short v3)
          throws APDUException;
    
    native public void sendBytesLong(final byte[] v4, final short v5,
                                     final short v6)
          throws APDUException,
        SecurityException;
    
    native public void setOutgoingAndSend(final short v7, final short v8)
          throws APDUException;
    
    native public byte getCurrentState();
    
    native public static APDU getCurrentAPDU() throws SecurityException;
    
    native public static byte[] getCurrentAPDUBuffer() throws SecurityException;
    
    native public static byte getCLAChannel();
    
    native void resetAPDU();
    
    native void complete(final short v9) throws APDUException;
    
    native void undoIncomingAndReceive();
    
    native public static void waitExtension() throws APDUException;
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1186598018000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAN1dfXxU1Zm+mckEAoFA+IqEQIBgADUJnwFjW4cQIDHJDPlQ" +
       "RHF6M3MnjJnMnblz\nJwRsxQiC9GPdboW2yIrt1qLW1ops23Xd0m1rt7vUSi" +
       "1UWFtrtNtla9tfTdvVtur2vOfcj3Pve2dy\nk2i3v/5xDjdnzjn3PM/7nPd8" +
       "3HMvj/5S8KUVofzWWLRa3Z2U0tXNsWhQVNJSJCjHd3eSpFD4wdeK\n3u751y" +
       "miRyhoEQrFjLpTVmLqblWY1nKr2C/WZNRYvKYlllbrW4SiWF8yLvVJCVVS0i" +
       "nhdiGvRZgS\nS6RVMRGWWsRuKa4Kc1rI7Wro7WrikFRDfyClp7GcakxUpcgm" +
       "Re5ThYUtSdKQnris1kgDak1SVMQ+\nrWywIS6m06RYAU3VbzcxnemmGejfA4" +
       "pQodegQWT4aGEGcMVnamc/fvOXp3uF4u1CcSzRoYpqLNwg\nExAD6nahqE/q" +
       "6yZw/JGIFNkuTE9IUqRDUmJiPLaHZJQT24WSdKwnIaoZRUq3S2k53g8ZS9KZ" +
       "pKTQ\ne+qJhKCwTDAqmbAqGwQVRGNSPKL/5YvGxZ60Ksw2kTO8myCdwJ0UA3" +
       "ajYljSi+T3xhIRVVhgL2Fg\nrLyOZCBFJ/RJxHrGrfITIkkQSpgd42Kip6ZD" +
       "VWKJHpLVJ2fIXVRhbtZKSaaJSTHcK/ZIIVUotecL\nsp9IrkJKBBRRhVn2bL" +
       "QmYqW5Nitx9gkUFL31oeDrFR7a5ogUjkP7J5JC822F2qWopEhEaqzgG5nq\n" +
       "e5tuzMzzCALJPMuWmeXxL/lKV8ul0wtYnjKHPIHuW6WwGgq/uXZe+XP+nxZ6" +
       "qcqScjoGxrcgp10h\nqP1SP5AkfWu2USP8WK3/+PX2b994xyPSq6RTNQkFYT" +
       "me6Us0CYVSItKgXU8g1y2xhNQk5MfJPwR5\nNBaXAPkEcp0U1Z30eiApCMIU" +
       "EuaQMA2CKkz0Bzd2VZNepgqLiTKvSivhGjBxWFQiNVHSV6RdstJb\no+cagI" +
       "qm7crLI82dZ+8scaKzLXI8Iimh8IlX/uMDjdcduttjiEdrAunUev3VRv3VUL" +
       "+Ql0frnWOl\nAXiNgM/4xcn6aX9zVfrLHsG7XSiM9fVlVLE7TtAWifG4vEuK" +
       "hFSqm+mcRvV+X9RNJEbUGoqTilhv\nTwr9irDILiWzyzVprui2tW3C4fmNR8" +
       "HqYKWZUDtrGuG8l7WtaFnHjub3373IC5l25RNuAckii7N0\nqDsU/tSBl75/" +
       "duLjMz2CbztxaumNUlTMxNVgwwY5kyCeYaaR1C4Rp5Gg/q9FmMx8g0j6t95D" +
       "JyTD\ntAz86SE5FDM/TSKSrRwZbSgcnDGr7cH/Lfs8U7mdoKAih6UI8V5mgV" +
       "DtqoVtD6z8PYFAOjBpmEqa\nBf5gvr0DW/pcvdZBVWER8gf2m9Trvg6QkLtM" +
       "jspKnxjvNHw3cXXqTkXeZaZQpU6l19OJOSaSMJWE\nEgiQOAOimUzPEFWCaW" +
       "1gqRv9TdPBLT87s3SHh/e4xdx41iGprP9ON5XRqUgSSf/xJ4MfP/zLgzdR\n" +
       "WWi6UMkglOmOx8IDtHGleUSGMxx8SXXpzHuPLDv2vK67GWbtfkURd4PsBgaf" +
       "K//Uv4l/T/wM6fvp\n2B6J9nGB3knQbwBxNb2u4X4kfc28vylUfzpNbEfczr" +
       "Y3V9/2x72XK+z+9tKkQWVmITo2k9EyplC9\nhcJfn7nv8KE3izd7QIqTiCai" +
       "ZJIQC5OZwDw0pDcYvxIzT4YRq0fPXI4yN5k/w1Awx94G7f7PTH3+\nuY2P3b" +
       "mQ3n9yREqHlVgSUGlOsUCVmwmdMBDSOyhiIh0nUwk2v+ikPzYOJJV6JiOIll" +
       "ArLKY31LOb\nkM0iofCaOy799onzX65iPWiBtQTKvfCL5b+ufPSWJbqd59sh" +
       "tUsicakMM6m88pWHX7tr4ucoMp+8\ni/a0BRxPSTIqh2NJkYwu+hVMfBRaCw" +
       "Dxk0aVIttp1dc/kBHl8t+HoTUcdKszM25R3SknjbuEwluG\nvvGTuz5ReoYH" +
       "bivA5V4xq7S0YliaRDuWYZDFNoMYBbIYhbTscivDfJt4oi8Mzn3xiivv+Q5r" +
       "nd2Q\nTiX+4fOvf3ZP1ed6zC6wUbsp/LPFyVg3kPmuaaz9y+9+4benVs3jjE" +
       "UtQPDuohmZPSDeYMBZ4sTb\nBllV5T6OvZXfqZ3jf6j1cd1QjUb5ZVZktpI8" +
       "vhVFn/nafz3y8AN6HU0UV4DDuJXGdUkN/ntofG2S\n/RhI8pmsf7Vqf21M6m" +
       "RZ/tJcEwzB9mnEJpjh6o6/r/u2333z/kkVpgXKqQOaCfMPy+hqKRYKex56\n" +
       "6eCy0uKLhPntwtSdYropQSZTMA+XFGKKOD8s2qeGtqr2fK3r/jeeUV+kOjXH" +
       "Nyi9aAC3/3qRG0zX\n/bB/esGXjvd5hAlkeKeDNlm0XC/GMzA8bCcT9HSDlk" +
       "hWP5bfrZNtNrM0x8x59jGTu619tDSnX+Qa\ncsP1JIcBcgUJcD2dGyDzhCRc" +
       "3EozXk7jZeZIlqbrnwFVqAiFmps2hTqaNocCm0LN/uv9oYYWf0dH\n5cra2l" +
       "W1a1esT1ucNfWCUoTNq78/edXdFWuiM2kvKaSmIQsvVZvITIQS+t+s1VM0Gd" +
       "VB1GvVJksy\nhdxr0ShKaR1FfqwU0qv6iKz6tUXEx+Z/9mdPvNI+08OttBbj" +
       "yQ1Xhq22DFCKsDDXHWjub12x8NHb\n21/sZm6sxDpZbkxk+v579zelqms+Ou" +
       "Qw9faS0ZXOeOicgK0qJUMCs0i4koQZEHgJ5BmTG9BiNR2D\nJaXk5Qc++/rg" +
       "wXUemHz4+kGzpEHTzHxtGVgMH3j0cPnke1/6MO3CMHeASu/CcvKqRLWxhEi7" +
       "5RUQ\nJYiupnR0+jsbQ01tTZ1N/haaP8lb/wC2/gHOmgeQNQ8g648i/+3arQ" +
       "dVIb97tyqZXN7jwOUacFQQ\nrFzCxUGdiPsdiIDrj1hYmM1YCPrbgQXCRkOg" +
       "taltM6bjOKbjOAfvOIJ3HNHhLj9E95nwH3SAv1L7\nd1YO+I+7gj+Dwd/U1Z" +
       "IL+0mM/SSH5STCchJhd5ffhv2rDtivImE2hBzYv+UK+1SGPdDVuTngCPtp\n" +
       "DPtpDsbTCMbTCLa7/DbYZxxgX61tLszJAft5V7DLrLBDLY1tmzu3hK5rC9zQ" +
       "hjm4gDm4wGG6gDBd\nQBy4y2/j4MUsvb4UQg4Ofj6WXp9dAq9i+K9ycF5FcF" +
       "5F8N3lt8F/LUuvvwxCDvhvjbrXZ8f+Nsb+\nNoflbYTlbYTdXX4r9rx8B+zX" +
       "kDAXQnbsedNcYS9n2Bvb2wPtobZAqLM2tLmxs72xIxho62hELORN\nRyyQJA" +
       "ODfr01S0qr+/w2FuY4sFBHQhmEHCwsdsVCKc9C54pQ06aNIf+GQHsnJqASE1" +
       "DJAapEgCoR\nAe7y2whYnsX5z4OQg4C1o3H+jICmAIZdh2HXcTDqEIw6BNtd" +
       "fhvs9zjAXkdCOYQcsJtcwb4Mq7+9\nsamjo8tB+c2YgWYOUTNC1IwYcJffxk" +
       "Awi++bDyEHAze7833B9kBnoCHQEmpt3NjkD7X6O67D2Hdg\n7Ds4LDsQlh0I" +
       "u7v8NuxhB+ywdlwAIQd22RX2EgN7543BxizQkxh6koOSRFCSCLq7/Dbo/Q7Q" +
       "l5NQ\nASEH9DtdQZ9sQq/FmPdhzPs4DPsQhn0Is7v8NsyHsmBeCCEH5sOjxb" +
       "wCYz6CMR/hMBxBGI4gzO7y\n2zAfc8AMM7tFEHJgfsgV5tm27r2xcZO/q8Vh" +
       "WHsYw3+Yg/MwgvMwgu8uvw3+Yw7wryVhMYQc8P/Z\nFfyFNvgNgbZOf0NnS2" +
       "NHB+vzfszEU5iJpzhkTyFkTyEm3OW3MfGNLExUQsjBxPfeGSY2YCaexUw8\n" +
       "yyF7FiF7FjHhLr+NifNZvP4SCDmYGBql12dMdHU4QH8ZQ3+Zg/IygvIygu4u" +
       "vw36pQGMwWNiYL+W\n0rUNe9BWbj4mK892WoHu5h3c9lrRAfFbO/Qt+DtVoV" +
       "CVk1fFpX4prlXbjytppYcz9A3fTxeURPJb\n1pXad8nnoAM71nKh8E+/dGrx" +
       "YOGPTv5ZHj8vyAkiFFa/Ehp+fu3FpXQfmN+0nsQq67RsXS80hAgb\nLZfrgR" +
       "MitR+JPHkOClSFgoQIG6ucChnfWZ6X5vyRDGM9khpUZFUOy3FduPBPF5WS8b" +
       "AV4jXOdYPC\nPR6kcJJErzdy11uypLRyKQHueitOoW2Dy7z/M4gs1HpzFQQn" +
       "IudiIgGRxzcu6qYT6lrknlhYjDfs\nFBMJTfhJS7tmOLTL6SF0585YWnsIfG" +
       "jvg4NrDu5/i+rJE1bh/I35nBROZPDnk6KZeLzN2CyH+GqI\nSkgDK2nVFXK0" +
       "Qt0pVaSTUjgmxiv6RSUGB1AqFqnknouMJ3fGk7cGgkVW0QPfnwd+9fU9Sek7" +
       "epd/\nL6U3+7mY0QmoDAuojBNQGRJQGRJQGSegMiSgshEEtFQPTgICSj3zxi" +
       "uWNpnoJJaIJXo26Y+5rGKZ\n7dAGyOBZwkwKl0tpwrIRyKfVctv+E7plOS6J" +
       "Cdf2qMf2qOfsUY/sUY/sUc/Zox7Zoz6HPUo0r7gM\ngpM9bnAe1zy+FDeujc" +
       "1QhcRQGzLRqHa6M2lp1DyHRjHOxv6oOVsefGCQnp9hj+xu/tUc8V/kj07z\n" +
       "CPlkzOkW02yEsZ+0xAcpLecjKaFFFoSl2RDC41QPHRs83bRrJ5NJ12rahtW0" +
       "jVPTNqSmbUhN2zg1\nbUNq2pZDTbO1dR8NTmq6w2GcNdUE0fjG2KlEUk2JDX" +
       "E53NsR2yNZhll7R/Wld8qK6prYQUzsIEfs\nICJ2EBE7yBE7iIgdHIHYK/Tg" +
       "ROx97zKxxYTYQEZ1ZhZu9CHXRB7DRB7jiDyGiDyGiDzGEXkMEXks\nB5HFAt" +
       "uJgafYVzoR+cS75+8KYGDyb7Q5O2jRZQ4tGttoBD+7nwqcwqY4xZniFDLFKW" +
       "SKU5wpTiFT\nnBrBFDD0wGb4VU6mePadNkWedu7WaoAJAnsmA+eep5DpA9DY" +
       "OBCW6GlAdvD5yhEOPluyc95mlipU\nZDGUUQRWBmnauXpkMl9xUMdcB5LGrI" +
       "5RdNSzWB1nOXWcReo4i9RxllPHWaSOsyOoo5aEaghO6njt\nXVUH1HTB9G4v" +
       "ECvN4qxkzi+z2Mve7D+HvYaxvYY5ew0jew0jew1z9hpG9hoewV6wMoSm1TjY" +
       "yzt1\nDPaymISefpprX835lR5tMbfjhVu+e+BM+Vm6U1FobEvAwi4GB4Xtr5" +
       "7IEf70uGU3IZNMSgq/WeHp\nj8FVjK36DNCXa5a2g1aFm+FufbKS3BkLVxiL" +
       "Q3YovUJUejLwWlNFfy2ksnliBSevFinRo+6sWNoN\nTZAiFWK33C9VdO+uuG" +
       "351RUfXMa0k8csANwWczRDNM0Vm5ATjt54S6G4F57He+eOuVZ8zrEr0ZuQ\n" +
       "dyXYNHrlD5/57g82DnxRX9NOSQ7ktDncsBJWc4gW+osg5O4UDgdvteZoannl" +
       "8dXfS3zy7n/S23M1\nQ5xk3FJulluSVCKCWqOzEc7snY0kGV1Lv96SJaWVSw" +
       "lw11sdUuznWFvksBg398RmfnBD3YkfS4+z\ntw9yHlu1lfz2kZ7Vxx97zKdT" +
       "0MNuy85zet+L+ysl+yMDJhPZVQQxPN73+iGqpRVSbwZXDfRqLF4Y\nSlfR3/" +
       "iDdv1yLOLWS+oG5Q1XzBmuGBmuGBmumDNcMTJcMe8lVcHbX1tl42DMyCHa/B" +
       "eK1GE8uEIb\nwwE6Gg8czguPejyg2jNuCTPo1Q63VIUb3HnjFZw3VqSwFOuX" +
       "NuxWpbR7R9zL4YMoPjpHrFAz07/V\nsdaaoo7TjWst4jGm3HjVlO4Ve7Gj7O" +
       "Ud5QpThQpWocKpUEEqVJAKFU6FClIhn+K9hqVoPuzjEL3P\nbFB2siHOQHQv" +
       "RAf1wsxfHRlXr93LfrP0jPkOMnXaq24mw542YC3/wP6dTwhntlM/Pyks9yXl" +
       "hKQ9\nXamyzUtmZrmFw/tJxh34Degz5+/53i/feHKfsQFNt66Nt8sa5HhcCs" +
       "PiJV3ZleiTI7Eo3efukNQ7\nyv/u+/fcd0cXO3t+5chlzPTLNgh3nLnl9fkU" +
       "YF4YXlo2X6Ezs7E36ebY37HcIqZ3kvtfiD+//fCP\nl89n9+fet9N+f3LjXY" +
       "ePfPUrq9lrmEWEn2nvuxbELXioese0/ZtFT3uo8Ew90VpdT+e9+LUFby/X\n" +
       "cXpRx+lFHYd7bcGLXlswUlL6QLWiyib+cUoeLu9jPe4YRPczRN7jNP40jR+0" +
       "GgGSHsrVR+3t/Ism\n1WFMhC4Jz8RXcN0ypXv3c2MYE8e9pm1KEGdCZtf+RK" +
       "SdDQgODmuuQ7PH1mFGZ6/z2F7nOXudR/Y6\nj+x1nrPXeWSv8znsBbuucIoD" +
       "Tu2tdLLXWPYgPCybjeMl2vzFfivWFSzZahyyqcJWd1OclZYFZyKS\ndX6jT2" +
       "4EcxoyzAGH6Dcj44Nsb3Bj7h9of/4jRG+OtWbIUJlyPcspNGCmRjXFGcZTnG" +
       "F+igP0e7rN\nSccftElHfnFKn3SsdEECxG9BMbqp1a1XQCce+SX0yjp1MbQA" +
       "3XG9oxY63WlhlVst8HNdaJYHwK0y\nOmn+LNRJSZLRJfXrLVlSWrmUAHe91T" +
       "mFsk1SNLaXGGyvsvLEckEMr9jkz8kzmIYTIPmX6YUZ00tT\n4xjv8idA3e4X" +
       "Znijzstt1HnRRp0XbdR5uY06L9qo81o26mDEXFllU5cbrqDgqiobWX+VFDn4" +
       "fTgc\nsAoC17NSmpPKD4zB73vZQzmb31+mdWT7rWx9fZm2tLVnU4Uud319tV" +
       "Nfb5ETPe58f36QAw/R1pEx\nQrbrOYFtozq4EaLtY605Zfj+VPYBAI8TqjDF" +
       "Ajo1mpGAtNA+EphJ4HhWpywjAQGq+aa+lO6bVrug\nBOKbIEoYfZV+h8qTsM" +
       "jgqixqYbUrZh/KxyvvfG4lnY9W0taUVvf5IYJDCpDGeElwP2vtgljVc2YZ\n" +
       "0taS8F5HmW9zJ/M1o5G5fVh7P1hqjcnffszffm5Y24+Gtf12H6SnBLjrrc4p" +
       "TDr7denca0hnDXbV\n+ymZd0F0IM+QzWGI7tYLs2HtE6kcEwhYcm0ZD9trx8" +
       "32WpPto5jtoxzbRxHbRxHbRzm2jyK2jyK2\nj+psP2KwvRazfZSyDWd984+Z" +
       "bH8eovv1woztL6Syj5D2abFlhLQNChO07Rs4qFZIFmkdUjgDX8mz\nPZWu4p" +
       "9Ka19cc8ppfSBdZr5+j3JTpPAUzP1IrbtC3m5Bzm5BZLcgsluQs1sQ2S3IeR" +
       "k6mVltTmb6\nxuBtnHsQVLymytaF3IgBCq6tsqlhzBqAKk4aqfn/+JdvETaS" +
       "G9rVT3XAbAUGRjR3eolmHceaGfmx\nKm1RbL+lKuxw58fqnJ/C+hORDuLVXO" +
       "/+5w9xKCF62T0YyH6JGvt/IPr5WGtNjW5xXILhpkY1NxrC\nc6Mhfm5UZ8ry" +
       "EpblJU6Wl5AsLyFZXuJkeQnJ8hJy8Jc0B+8rTOkOvm4E3iF+FYpMgqu39MLU" +
       "wfuK\nUi7W42OW4bpxyRCa+2tAuM6g3IefAPq4J4A+9ATQh54A+rgngD70BN" +
       "CSQiknKRrlCwzK1yHKffRo\ngQ807ZtuUg6vR/pm6IUZ5YtS41l1/i41Ks85" +
       "hCU6xEl0CEl0CEl0iJPoEJLoEO85YeSoq7LJzA1X\nUHBdlY2sv0qKHAYXWA" +
       "PBe5ZruC6W0hykz+Ht8Xfq9CacgG3IKArpqvBNX6dN8sscmkZ757t7jNOH\n" +
       "33D3NXPdvBl182bUzbk33H3oDXdfcw6bzNZsAmu3tU42kbBN3oGjyXZhW2dN" +
       "7CS4Zi7jLY2kYQb2\n0tU01wxHMcNRjuEoYjiKGI5yDEcRw9ERGIbBBT6bUe" +
       "fE8O3/LwzPtDLs+CYHNH1ulqZTmHTu7jtk\nzt316zp2jWg/xNF4CNFoSWl1" +
       "n5/2t1G8ZuHbi1u2lxPEXiSIvUgQe7mW7UUt2zuCIGB/Er6nsc5J\nEJ97Vw" +
       "Rh+sIpYPoWv+VdvLG8zOg7gWk8wdF4AtF4AtF4gqPxBKLxRA4aYXk9R5u0rX" +
       "ei8WvA2bje\nRStUJDKT0zy6+1HWdxrzcprj5TTi5TTi5TTHy2nEy+kReAGJ" +
       "wbe6rnbi5QfZecl9QgvYXuBQsyp0\nuJsir+emyHAEJi6pkuv1me/c2CFAmY" +
       "t0IvafEL0w1lpTrpdmE3V8qdEsyEhr7AsyMwkm4+tNkV3E\nIrvIiewiEtlF" +
       "JLKLnMguIpHxKWx1cFFfHfwhpa8O1o9ANMQ/gggemPp+pRdmq4O3UuOY+vp+" +
       "NrpO\neQ7zdY7j6xzi6xzi6xzH1znE1zm+U8Ikf32VDfNfJVIH9wOnLuohpL" +
       "D7KViYvZe5dMuzib+Q8bmX\nUZFUsAiRRJIMSvTrLVlSWrmUAHe9Fac4kaRP" +
       "AeCDctc4kZTl82Hv8JzQfp5oyi4xpjYOqFIizT6l\nPgo+8ZfKCuo4PusQn3" +
       "WIT+5LZQXoS2UF/JfKukhj82FchsOEpeg/dWH/EUl40XPvX/rN5PR/Z+/+\n" +
       "6v9ZSKH2LQD+o8ncdUFSkaLsTZFC9gllOjUqCKpCCV7ukTmCcQ3NKwiw3B1k" +
       "BNBzw9+djJxZKv/9\nXPbNZ81U9CsgOb+o/qmbPpZM1PpjWT7YDwn6Z0mS1q" +
       "8xw4dBMuz/yAmFf5G8ZfML7T95RPtMukGe\nNKBW0/89R/96h1Fi2xduqhj4" +
       "cOffsq+ch+Pinj1ws4ktwgQ2xNN7w/+vszBrbXpdsZd+GP3Qvp8W\nW74/zx" +
       "Z100wi5mevB66vn1J/4bonn3zI/j0UgeOSg0/L6C9OrF76uwlvPDN8rQsW/w" +
       "RtFfdxE2kA\nAA==");
    
    public APDU() { super(); }
    
    public void jif$invokeDefConstructor() { this.javacard$framework$APDU$(); }
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1186598018000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAL28eazs2JkfdrsltdQlaaRurdbaknrslmk1i2SRVTWSg7C4" +
       "V7FYXIpL0Raeue9L\ncSsWJzEy/sOyM5gs8IwRB4nHNrwA8QSIk8Dz18RGZp" +
       "IgcQIkA8SGE8SJY48TwJkAWe0AiR3y3rf3\nfa9bo9Fc4OM9lzw83+98+7k4" +
       "h7/0mzcfqaubt8oivQZp0bzbXEuvfle0qtpzidSq6+N444ED/bn5\n5//KH/" +
       "yrb3zo5lPmzaeiXGmsJnKIIm+8vjFvPpF5me1VNe66nmvevJF7nqt4VWSl0T" +
       "B2LHLz5s06\nCnKraSuvlr26SLup45t1W3rVLc9HN/mbTzhFXjdV6zRFVTc3" +
       "n+Zjq7PAtolSkI/q5rv8zWt+5KVu\nfb75wzev8Dcf8VMrGDt+nn80C/B2RJ" +
       "Ce7o/dZ9EIs/Itx3v0yoeTKHebm68//8bjGb+9GzuMr340\n85qweMzqw7k1" +
       "3rh58w5SauUBqDRVlAdj148U7cilufnSCwcdO32stJzECrwHzc0Xn+8n3j0a" +
       "e71+\nK5bplebmc893ux2pr26+9JzOntLW4bVP/H//oviP3nr1FrPrOemE/y" +
       "PjS1977iXZ873Kyx3v7sV/\n3L7789yp/cqrNzdj58891/muD/6Tv6zy//Nf" +
       "+/pdny/f0+dgx57TPHD+X+wrX/11/O+//qEJxsfK\noo4mU3hm5rdaFR8++W" +
       "5fjrb4+ccjTg/fffTwr8v/8elf+Le8f/jqzWvczWtOkbZZzt287uUu8bD9\n" +
       "0bHNR7nH3Xw4HX+NM/ej1Jtm/uGxXVpNeNvuy5ubm0+O9IWRPj1Rc/MxXCTV" +
       "d+PIb26+Ndrpd+rK\nAScVO1blgn41Kv1SVAn4qFc/DfTJyyuvjHC/8rzrpK" +
       "OdsUXqetUD5y/9vf/sn6N2f/yPvfrYeB5C\naG6+8Gj8dx+P/+40/s0rr9yO" +
       "+4VnxTDJ1Z3M/3/5d7/76X/pO/VfffXmQ+bN61GWtY1lp+NsP2Gl\naXHx3A" +
       "fNrd288ZSN3prGaFefsEcTG631QToOdGvSozC66uabz5vSEwfkxpY12sdPY8" +
       "LNL3yN+tcn\nrU9a+uw0+h20UebJHbZPfFv5/vYP/bFvfmjqdPnwKNtpJm+/" +
       "/+gPHPEznxP+wv/95b98Z1XPAxKr\nwvHcMXY8eeHBHPmG8Gfg/+fVm4+MDj" +
       "OGjMYalT7639eed5hnbPy7Dx2iufnme/zveSbffRRbJlG9\nyt983C+qzEqn" +
       "YR4FhFkTVsXlyZ1by/j4bfsn/undzz95SP90jBtEkZWjTVZvMd6I1Wo8t7yz" +
       "peny\n1iTW5yZ+G8L+D+4H7D/4G+98/9Wno92nngqLitfc+c4bT7RyrDxvvP" +
       "/f/Wvin/iF3/zBH7hVyUOd\nNDevla2dRk5/C/Rzr4wm8Jl7/PjdL3725//k" +
       "t/+Nv/VI5595MjpeVdZ1Unn/M7/+1T/1n1j/5ujj\no9/V0eDd+tfNLaebRw" +
       "ymK3Db/n1PPXz4dLLA572IngL8Iz1k9k//X7/6p2dv3eGY3vnS7QhfqN8b\n" +
       "0J558YEz/Afqn/7H/0Xzd25F98RKpjG+1r+XrWY9ZZKrv9m98dq/84vZqzcf" +
       "NW8+fZuUrLzRrLSd\nBGuOaaUmHt7kbz75zPNnU8RdPHxieV953vKeYvu8zT" +
       "0JGmN76j21P/q0mY2C+NhI0EhvTDTd/PR0\neaN/5aacGqvbjt+6vf7uJzZQ" +
       "3+bwvrl568GDLUc/UDjmwYF+sMU1/AHB44ryNjyfI3MMWt8jZ7GK\nsjEudw" +
       "8Tx7/6tT//D/69vyd/9tWnsuu33utgT71zl2FvJzIr+5HDN17G4bb3rwHf+K" +
       "U/LP8d+y5G\nvPlsgKTyNvufrr/q/Z7v/dzfvSfcfmisAW497VYKi8ei+9xI" +
       "k01+ZqKnRffKY3eadPguN5YQgVe9\n+T/+mT//j37mB6tXJ3P/SDfpeoTy6S" +
       "f9hHYqhP7oL/3CVz/+8//Dz95a7GTr06DUe9XwoWbUdpRb\nt/n5nenyvVEf" +
       "n1SO+JF6wAnckcP52/7/THnnLHhz82H72ngvmgo60mcnenYqU4N5hEO6B8fU" +
       "5p8B\n8fk7ECIuTyBGMMRhzwnM9Fh4EXf44e/PvYS7/oG4f+aOO63yH5D1d0" +
       "b6/EQvYf39D8T6J+5YH9Qj\nc3g/rj/1sIz4wku4Oh+I65ef5fqApwTmyD7Y" +
       "CQddeCmESeNfnOglEKLfisY/kAAmjf+uiV7Cvfih\nNf6BWH9vpC9N9BLW7Q" +
       "di/dU71pQsH+QHwuHBcf6AoY4ypYgHQaFeCmI50pcnegmIn/5AIL74NIgj\n" +
       "9ICjyQf45iAf39fsvzLRS/j/zA9j9nf8ucNLua5G+upEL+H6gw/E9Xe9V/Qy" +
       "xSmK+nKxT2b3tYle\nAuDnPpjZifLheCAO/IM9RXL4gz2u7F7KesqzX5/oJa" +
       "z/xAdi/eZj1seTSL0/59870lsTvYTzn/pA\nnD/+hPP8fVl+Y6KXsPzFH5Yl" +
       "9FKWUzz75kQvYfkXPlg8e061JEXjKv9yf/pnR/rWRC/h/pc/EPdv\nPMedOA" +
       "hHnDjylKLc6Rt/XyBvT/QSIH/ltwfI5n3t/ScnegmQX/4h7f0OiKq8h/N0+c" +
       "Y4/FgWIe/O\n3701zl/5QIN/IU6dtx8trzSvqqMif3tcqt++9mbzdIl29x+b" +
       "e7iOFd9PPOnGF3nw3Z/9+//Kf/4v\nf+u/H8u97aNyb+rNjhX0Z+m//t/+l9" +
       "MfvzZd/lpz86UJglK0lePxVt3sCzfyI899jOLpGi4t7kXQ\nfFNgFzWHP/oR" +
       "INc3ehUyMyBzEgovaBzgzpTEbQKcVLf5hY71hSNxJLslxVSSWRrbI/s83ub7" +
       "3E6H\n2fYi170UEWtGdO1Ch69c1UBnXoeKsoYRw51nUNUsO1WJIFWnm6oRmt" +
       "RaN/7R7bSmreDu4DsxInYe\n7F5nCRwhHYj2ZOzmQ5wj4h5c5qK7Qth9F4Oo" +
       "stqpWuEPus7LFmLC6rwxhFoPJU3YKlsiZl3EU0qa\nXFxcbzdD2iUKXbNIvo" +
       "YFJVV0zJdHLePPdqqfoHxXwQSom4J86nanNE3tSl8okU6vrnynbQlNU+ZR\n" +
       "HroR08lmoMwUTNb2MqPrtdzurMXOgSpuqVfFSFFCy6R/JdJyyThW0qulE2Sy" +
       "hx7Dk9oo7k7Kq6iG\nkoC0EkjR9hIwq/TrhVOwbI7JJ1xFNHtw+tzLMsaLfX" +
       "xRSoXrBZJ+XFgMxTh7bVxlOKDfHYwSaelF\nCxGOMsjFqTzzwiWYUT1OYrkV" +
       "ninwjF3NC7hlOFpI2iO15tSzTKrZNhJ5izW30hFe6COgS85ZhSmr\nZ0SBEx" +
       "QJVqay3pnl7ijNPOC8DXfE5Uji58zGz8xF0mRGUMQdD6KnjulNbL6rL3ByPK" +
       "yyK+FetnMV\nR6z4lMZKBByRPuRkTQsDHqaDWcVfDyaxobegvO3Ziqn8cbWR" +
       "JJJSBu4C3kUlZpKavtuyJa9tYZ8z\nNDm0G3OnWNZWObLODjQ5TlOLxnP4WV" +
       "2uuSrZ7jYbWQ61HLZ5KTuddVSImn4dJCrNI1DhkRUtLy20\nCNQ4EZdbdEus" +
       "YJiGz3pRUiFlnYeAQfPzzEObdtgPA4HzW3Hf6pln9DyY7rRVm84vzSmPd6zI" +
       "sa2O\n6RcmOIOtYXqAIQL5OP+zc1acuGD6yglKaB7OziKkiCie+HoLq4q40n" +
       "cICIgGbK/Xi/4qKmdMPgpS\nQp+OmYep9Zw4aQrX7AJDXQXQFe7D8SG697fi" +
       "RUZnwsYycDGhnHI++iQy9yK8JPacSrWWtMdhYpcM\n883gwpopeGVw5qPjrl" +
       "OiLmTiTa/TUiRorKJhsls3W3tWAI4VcOds6VQ8t4JdE1jVjrUbeINbcVEW\n" +
       "rrjUANv96G2O2zZNHFFuhbe56nWIJo+k8oCUzv0q1w/pDDciIdiDi97JMctY" +
       "D5pf8WzNLA0l2q99\nLdV4anlscD3ymUVHtbuQVs5TTJE7DTDWsrClbJUpzs" +
       "coDbvZ8VKto4rk+EgfroNWVm0ENzpCLPxM\nkFfs+bTTTZVsKqZlVulSbyw6" +
       "Z+PWRpAlwhFoCqOy0OJOEkVLYT47k7UKNsomXaKg2/LxfoAJe2h6\nq80ENT" +
       "3ue0ELLpcTmlwJ72RZMkQs5BJlAvC8prN9vwrmMdasUXJ7PZKzBh9WmEKhNL" +
       "kHj8pOqeSL\naSuBk5NMtXRYkPfrlbrM3GKHRyGmcisNzQKNbM6F1pDYsBJP" +
       "NH6IN2VGna3ZxkeDrpqTOlg6nWtu\nNJ2SV4EPZ+tj1QWYlPDNPq7LXd7Hnc" +
       "BeEMcwzsfE8EzLlEoVS6H1YXtQLGW/1akZFUTSAT9EmTqI\nFK0Tlg4FZ7lb" +
       "H11xwx9XyxpR2BD0Fr3bL6CIKStxfRBQQz6rgaL4YL9d7H0RHPhgcOWZrkeY" +
       "uk+C\n9JAd+hVHNiyTeqrC7Pt+pRhGObCtyJMd3O2wJaPbjZ+osrsQ601g+T" +
       "sQVLtFCh7Byx7zu3IGb7Dt\nOmc2SJJL9mXTCzbcLoxF4jvwqrumqj+Ugk35" +
       "zlCdEG0Nwv0SNnbAAKybXSLpWsYdCzhZU9cyJdaz\n0Nn6+TLvVjsKiQZ3KX" +
       "GjzRBWZG45iUAP5oW8zEvSOXU9NxwXJ/k890WDW1wFNAEvEH7p1wtm6S/F\n" +
       "I4sAs/YEi4idSUi+vsrUmU21QFGZ9FCrhJZdMne/IZXDNYy4cJ6rlwTugCgR" +
       "h9Nhu9WwbXTg0hSv\n+N0JgfiDPUv286jwCetwXa7XRT4YGBqJerRppNEJfY" +
       "JHbaD1RUXf2mcXXddho9bRmBD2eyxbrUqd\nNZZNtWidYl8Cq1kEWvON3IvK" +
       "kTuHsLBNTpcWCLW9v5Et4kL2ydzSuKYpIdcBkw2brhqALY6q4+7q\nYT/aP6" +
       "IkeWy31CVtmVnXMcd2QGWvOLF21OGotujPS2V+SiNLJlv9ZJK0UOxPG5s7hf" +
       "axdqKO9LfN\noohW+yFH+ijqOkBCq9yFpdkxMoCFf+h8xBQhz8UGAruodl2C" +
       "vEhftQBJxKy1rGF9BdbAwvZyrUbi\nmFIbSSTbIsxMUSG9035jLuqjPdukqY" +
       "YesUNnGv7ZRGIfiyHHhaRYtVFTM5Om5FZdqNE5mFv+gFxX\nuICx6lzVFiTZ" +
       "bg3GVRMBzJvCZ2BlBsohtyqz2l9qZx+GRrnKJthsHeoybNZZTm3LOMQKDKzA" +
       "FkYQ\nZACTRCsDY3eWDhbh78UrEJ538mnn9Sg2wzziOm93fCjmzWXM06eqKC" +
       "XFPO5xwKCZ3e5Armr47DHN\nuYL9HVKBseepGpAcYoMVrtHawgkERM4yMx+M" +
       "GWhvQK9mjLhz0RBPE2/nkUKazQ0CZPYDvrIJ57hm\nFTJNQl1Ebb8yhUao9v" +
       "N+1aPreFQeBq0bUskNQLJmTi1CW87ZOIG6dUjYZa7kEBKyg1DFYCTL2PRM\n" +
       "Lj3b1VibaWc8orOx0gqPZ0soHCKb8wLYduvidNL9ucvOUKey4FSHLMirj1Dr" +
       "CL5OqMVROC9XoOca\nLq230R5Oup2lZJxUd5rZjVlaUoAGqCFtP2dcbQMxY0" +
       "mU1NdZ6PbVXAl3Ywyl/fNFnZ87LNoNWKMa\nVA+Y4DpzxU7ggPnq0DQbO75K" +
       "kBGeYZikiV1Nkgarj0EcgvuVwNozGAJrM8PqnixNO+kToEOX68FL\nz1kNHF" +
       "rpsvYtZW4aB+8QOcFuft6qe6KeR4ukkEyKDbboJjsy600kyDA521pGgkoOAI" +
       "BVcDFUL2OH\nBZAwQ0mxx4HtG0YL9iwSzx0xTzwIxPYHhNizHq60IOF0u7PM" +
       "631IRUtUVqXZ9hS1ZS7Pgbi2pTnU\nHE1IAEPLElepDV4IGAzYQxZ4kiCtAm" +
       "yxikAAsSrJ1Th7vWyuZ9MQlvHloFoOLUmzih6IXmXcSKzd\niCOrGApP2R46" +
       "EWJlB5JByMkhaKy02WN2fNiNhI+lHrdFWIEN+XhNrdH8wiIK3kH8cuZCpwPA" +
       "Acsg\nBsiLC44lAscD82wPKgqLKkfCCbehi/p+2MEV2UQdl1FwuBlOHaDuAE" +
       "gZa3RSa495QIhNOSPHC1nb\nR2I/Em8tQdI+mX0fGBjU8PWwxf0G1ZYkX/Eb" +
       "kj9BTTa0SLhDK2I9SGGcLQIyW1wYBgvIjTuTNtfF\nFQbjxV6tO3uhSsHi4M" +
       "eYbpRrFz+vI2C3vjo0Sk+0EpC0WdEgr7Zdd+kJsgu72K4Mc+UDQm0DM6Hw\n" +
       "U/t0nMg1jEW1rvrVBhiNn8QNKbdrzxWck7LO4U1nwxexKWwTP/N7uOGzvl7C" +
       "PdeHBQaHFH+QhZl8\nvUpb/ED61RxS5ucKAC8w3Z4WNb1hpTCjWOJSu7VG7J" +
       "w1gY7V9xyzBM4HGImt8+0ZVyiI3OJWSQVE\nIc9wb3mFL+Eprw10WBzGWRJQ" +
       "gbBAzBEZzpluCLOGcyTPFHfBNkLjjpqo10OMG4lLHE6SU28b52Iv\n9uclsJ" +
       "7VVhYXq2YDOPAp0E8H9SgQEHc5jRnQ7xP8EgGATV4pFh+85QpBNutkkxcEK1" +
       "FZ2SBCnJBL\nAztgSxJm3WC2JOsFT9ZSGs65dtmthLYPN8D14qYXnJNcGJYN" +
       "mAqEJbpANn00SEkfYklxUGSaUAj+\nPGm/AKWllKKCNBtnza7JxpXMdS2dQT" +
       "oT3XAQ6wUp1lKYz7l6YlBf2TrbeARBsWh9iHv7QpwGjNjL\nYLjf9BuGWwTD" +
       "YXmdwQPuOyt8v182NMVuA78ONLTJ4GUF9455AM8rLdTZ+nRBgFMA7i9BN1K7" +
       "arvp\nxmV5qa5auB9ltxJBc0b7V1roAiGwzYM/F3IFFtgN0A1+PVAqGm3LIU" +
       "yOV3okKkMOOrL3GYGnelWq\nxwpZ9D1GOcEnwvJ69bKaXa/0ko5GikdfqwAh" +
       "8gWzExcKQWYnZnNOIdjdu6y6kNiVKSGAGYDcNehG\nahcTOqyUmP1FF6ITD+" +
       "izeaUK3nqj2/Ei263WsF6wLRoizjqtZNyn7QMoNQDZaIVGaAnk06WxKKvU\n" +
       "GKNkU5YnZ1jjiH/sPVUWx9IdKg3LXeV5ge+X42I1XFEA6DJVfzow4rFDTTYe" +
       "Kys8iWjaAqmwBPwW\nGQeUxvIZmOejyrClXBvKah7igT3jTb8K5H3UyMBWZJ" +
       "MDkSp0UEgcg7UOEea+bmIG2l1lktmvk7BU\nTVo9XBHabcWNSKO6srJxbREb" +
       "B/ckEjNRxhJnu6Wqwb1CUHstefm6k9jWi5rDuP4nr8sB3C+CGmLL\nYYx/Od" +
       "eOYS9g5H5wWux8OmJpleRpeIpJv57Rm/326IdbZdlkB/7IYwo9R1foSc9rzm" +
       "fiLlgIFdmi\nYARUWwqyQ5BD0HwjH0yRzBNsZ3r8IMDElQWYMzdTxjX2Ds41" +
       "2tjNpWZeapZyVOMg66MOk8eybwPh\nZ/qcJ3nR7reIzyRLhwkSTZ9Lop9fXG" +
       "Dtq2vFS5Ze6YIzHlMRYJmd5lJWkHhbxBtBYuTtHSlesI+U\noA4pqqEl8Rhw" +
       "hBIjQx+1ulDmxXZrcVujgLETgFbMzpwtXZy5HjbmJbns0nlTXipuFJqvOU0H" +
       "UMsy\nPSjYlnB9+Lwf6eDX6gm8Iwc0i35pFgPGimoxr5bBfhaU+7Wd4x40XA" +
       "Ga9NrYgaTQkSVm4OUza2F7\nOC0h8srKMXvoO6w4aLXnM4SUl+swBvoWbFRn" +
       "pYFJPF8OM0JMk+GQ6HP4StUmMO9xp+Q9J95ZNE0X\nSgrLJLGAJJGV6xViy9" +
       "UWFbYQXFlho89jTRzrCCWz1VCAhwCa2apwhkuTPNoHyJVXwjE7YxeYcQRX\n" +
       "peZ+zMC7lFITeEsaFIoItQxfBTNM06UM6qm7Ou+wsjpJ6lBz1GgaHLGFqQ21" +
       "vI40GpDLcuxpBx4D\n+dCvl8Ou70/Hk0SZkBma7ZpgDXmzJEeKI/LK3NHAUE" +
       "ayH6mebVCWxpt2O65eTtpQyICjLFFgtTsx\n5NVeSugBjmVTWjRM0xQbEljm" +
       "l7NzOZ8WvZlHNMnTO13ZqeilPEb0cZZvqg1NkvMLYy80Fcs80XKF\nRPfcdq" +
       "lbBb7F8zrDAc8rUbLE1+TpsCF0jElxtyPRa0gdxLS9Oms0S6NSnZkko6qSrG" +
       "+y3GqNMtmn\n617du84G5ZmKQ2VXUAZ9A+UHQ3fG+n4RreU+TUVWt5RDfT0U" +
       "BWpRVhAesDxuZoamshB73KynJTjR\nCYtznwwRMMD7zluSANudrL47nVDvMo" +
       "/vCBrWYcmsw8K7aNhlXygZdIxP16GBxvLAumac4vllWRkr\nBE1ltNnbfhxq" +
       "LeABmz2gZZgK0YVNdWOqWjCbhdFU6HJU3nLeMirCmcJeCc6g7rHlLF7RWrxD" +
       "MFIg\nDAu14ACy6AygW9/eKcgm4bU+4iXkVHTqVvVi/qKnwhjp4aTO02ijeB" +
       "0d5XIBYLUuFMLsaI5Vr75D\nEGKtuQegbRkEhWTVN/bWPFk5NS5cdGeQSWE/" +
       "1zIUP8YNulAwZkGjS9YDvEOrmauhoqq52Uoz92qc\nBLZKSRREl8EKJvNeNt" +
       "bCQZGWSUPmTr3Z6s4i0IGiDtDDQiUDt2s8s7DyPF25hq8gw3WZgwqM7KGZ\n" +
       "hPYJQm/bNG2VsaIg9PNhoJxlnZ/mCaNBfLfGlK2la8olvUBQ7artkOt0l4zr" +
       "amS9kjM/35DIKfGV\nBTDMmsv6yqYtlPoDnJhLrb81fPc43wvtdYUOXgPwwL" +
       "VOgeue3IaiqUlSLwpLBIiYcylrin0xDdKX\nzzy9OM2U1JcRMCLdDrryB15X" +
       "gIJBx/J82GQt85AyUnD2x62z91ap5rC2ATXpAib3V4K1wI23gxhq\n1VKcPb" +
       "tcKIwJVs4QtKIXXwM4FlriKBaQhCEap9oIm8e0eUG0s3KhD60x1iJ6actLeT" +
       "3wi9O+EOOS\nrWh8mC9BbVa7llUUy2Os180iZjKEjbX0sNC8JRMvD6qLSuUx" +
       "lEq9cHalSlFnbYvvaBWjiZQL87Gs\nDM9aIbZDTPGIOLPpDVxH7EFipW7Mut" +
       "Cl7n1WTo1qjfB+Jc5jMTnsc8M6w4vsgi7GUgABLyLmHi9h\n3qR7ULwm9fpq" +
       "pOFOWs8MK7sOapOZVUZfxoVmHyIL0gsGFABRJAJ9j935tUQLDYYJzaq2UDZ0" +
       "iFqM\nthpipl505JZUgXh+mwjScnbtwBYAfcedO8YBaQDUCdNBPPJCECI5n6" +
       "drP1FPo6aMtIANjBrqJYVg\nnn1ClqzDjUvnpGv8iARA0CfEWbpa52vA95q1" +
       "APgIHxsnT/RFtTqPxUZG6VQO513b2xRvRIVXe3PQ\nbOgj0hYr6rKea6V7BL" +
       "w1wKu0fQWNmWOUcg+kNHtyl7bD8EZaX9SUxyRej66RDThq4fHtOha9xUkW\n" +
       "R8calzeCuJjHMjBnAkZh60qTAaQBuTqbQTq9D4nFdljJhiPMr6XRIQ68P1Er" +
       "b11m0I5iXMJsfEDe\nKS4pBQcya1tpKbJQRjMmBg4wvRxjXevK4AmbjekKyi" +
       "vR8HSlWw15vbHb1uEK8tjCjcvzhi6eApG4\n2rG3T+FuoP2o02llMK3wej07" +
       "W92FDk5qnmjzulNmroHFR3hBOX1xHXCGxUgnXizG9QayiZfhuvDB\nRSwzwK" +
       "HRbU7dplfRqUuBITI5NmjGMY85QwNRIM69ZSXMFMfxGypl/Zze5YhSuxRF9O" +
       "NqdG+fy3Gt\nbUiE4wGKMb/GJbS3JRwxmHXRnzBET8NUq5sVK7jW9sRedvPr" +
       "7JDlAC/IW8Xk5a1vVLyWKnqVqTjr\nraFjRtcJpAi8ZTDMtas7nnISal+t42" +
       "RYJUPGnY6cmBnYSTXn8+Y4W/Rxt4pcHPEWxpi94qFuGojN\nZbmcG7Yro+1p" +
       "jvHrc7GCxgIlIymDTlMVdezqTAbnqLB1A9BoMl/4x8CZ1XhBQEtByUpxRy6G" +
       "zRLp\nTGnIbAQCMlc/Liu9X/tmNi68tFxdqK2LQOtGE3wbpY6ih658BJPwCy" +
       "hDJdXPpMquDie6KYbzgrL4\n5oTNUdOPAU08bXBudTzHJI3HBZSVDN4IOECV" +
       "4XbBhnp5vcS4xJwBywLSA2ZrVRvMNuNamaOKk29q\nQLg6H+t9PMLvzydbrc" +
       "wQ3PXXrvOZRZqf1vq8sVSt81HutCWJkmQ8Kr2IcNcEaayNSy9zNnZQVjTK\n" +
       "Zvp62IJ7qEAZ1NfCpQiF59jJ/XFx4fsZeoIXANP4EMxiSr7h46pyFuWRrJau" +
       "lzvWPMxJw9ZmwDUz\n3Tk95/aANOgMt2xOfA2zDTXWzdS4dHSyuUmum3FJi8" +
       "B6OS5e0bgp+sGWe/aOhgyOr7tbGj2grEV4\nd+lka/BN5Urq7nq1AEybXXlF" +
       "10GXYmjGqvkaoyRs2XQa8pJAhIf5WP4vzrTJ0VnijjUwaayyYSaa\nerso1z" +
       "sLWjvOqix9ZeOaFQrEyPZYirg6iBBX2Q2BZOhmGMnknaBOW6mGaglWEM6TEy" +
       "zT0uaY2dis\nbzdNztaSxl+za2PRCBdsiDPW1Oc0HDZnfJcsrLOfg8DW7aij" +
       "pTDrSjsiBm7jKiPHMuIVacY6nsX4\nWT/bZZBs80C6a/vLaDXnfAsSQHiQyZ" +
       "bXjAMIoJd1vyNoDD7OT1cW2zLdGG3ECtWZRoh1tDc4PiyT\nEyT0FTFzsH04" +
       "aks1V9WVKu10q2J6iuI1f6VNo90mnpRvV+H2uto68w2wqo6H5NBlCwqJaIA+" +
       "lfvg\n3CLrPa9e/HY3U6OlvoAP+sIu+6tMWADc4O0eC0Zp+Lh4XmwXOLDGj1" +
       "KIjo0qyANyOd8IhCJFSb6T\nq5S4DDvoOiYKXy5mgbSaL82mVQOsk8EywzjV" +
       "RE+NsoBSCIwW0K5eoSGhYj2VzomHFG3FgtryBXUY\n10WeUpyX/HbAIWOmsh" +
       "s3PcF1Nz/vWPxk6Li48VCzaglMn4fXZADYZmX45zVhOQGDcDu8Ks/dRjAw\n" +
       "V1jVtZONNQW6bMZYfmBnCEIigiG63SaFVrCtDnaCICxSkIbrOxfMHgSzxrMW" +
       "adQFnNgbASmY+GqY\noQ67wpJQFma0jPkTnJwkGx7dSZ1Dl57dO4Ict6OTxt" +
       "GO4dArSTnyZU3JDGdvNkfMVj2fWh0QkL8M\nYkPyNUCcWIGF2vRsHjP22C7j" +
       "JpkNDQJhQwnHegD2Ar0ghHFdoqdQjoJwAzErs2XtCGrhtBcpI1K4\nTg0kb5" +
       "npS1Vt4KElOGYDUhWW1w66nVHb9VK7yCFQc+VJLPQO0NyOZ1bDIVgGerK6uP" +
       "QCb+4oOIv9\nZsf3Mr6wTkayHkPnvDK8aKV3ODymnJmsNOqW3B3nwxUDIFZ3" +
       "+2pwyipGj8foIbFXOKeuQCJ7OLO9\n2B5W5XaESr7pOelaCrqT0W6k+lrOZ+" +
       "22jirAy64sTm0jrEzaDso80IEJGs9OzZzrLJ/i5xcoLY9V\n6WYUoq3OLlVf" +
       "qbBa4vV1f0myBdAIiYZQM67quMi7RFST0lt+x+f7oOVKtt/pPeTQtM/6l7C0" +
       "Vgeo\nWOPCXgKDIPAysQRK2c3OiwOitocT0JWAUJWHmSctB/e0jLF+iB4SCw" +
       "05BQ0ZoK64xEdgjfQFf6tx\n7PpyyPm2CEueXO606NSZHuru22GsIqSVnY1G" +
       "a9JqjUeyvOX2Snd8JtXRlrNILFnEPYJ0mrFtHtMV\nzHar7SD5JVpco0Vfxq" +
       "fDmeai4YilMzEogJXp74i2WIhtLeWIzh0BlDclo1BglQa3/q5NwngF005Y\n" +
       "H6jSC0BXZ0FKTRdzQ+wMsBJQUQZNAARmWLc2lR0L8xIJFKvccVVaSSy+Ppo0" +
       "sQ7S9BCrZ2JXEoS2\nbJNjRjgSIuwu0QXZQMlG2AyXNeDG297cdeBYOYq2YK" +
       "4gdU3UwcEGCvCc2WJp7iGxjMe0eSIvOWbO\nMwU6r/rLwt2MIgKveEb76GjQ" +
       "/p5fHteoLDb7NmG8mbDb6HNwtZbBNRZCdAT3bnsO44VzGBPTGXBC\nQIzyeC" +
       "x1F0lzCSS4F4TlBQS6ethUtlG6tekCjIhIXbnSZ/pyAQ69Cc3nlwjNvG6DYV" +
       "0ObcGFXeQ5\nMnBgPFcD76AEc5DHiPWhopdYe0k7kRRWlVTr4EVuaN/tKTjB" +
       "Zzj++3//tLHkbzzcn/LG7RaZxyec\n4sifHvyHt9tQ+vdusnn1ySabRxv1py" +
       "vw1Ab8m2nf9ldfdA7pds/2D4z/7RN/1Pq17087oacXN83N\n601Rfif1Oi99" +
       "sv//+UH2t8euHm2K/7Ovvel+mF998fkDAF8a2X/9pW8+cJpffvC//y3sb7/z" +
       "6vO7\n6WeV17RVfnxmT/1Xn9lTP/1+c6Kn9j7dimu6/DfT5SdfesDhpQ+bmy" +
       "8+OgL09uMjQG9PR4DefrIz\n6G8/xjNtbv7dj+g+PH/33u3lr+XWtIf+qb1S" +
       "PwrijwdeI1ZFUzjF7ZZ14TmQrz/cLPZ7JroP5D+8\n5yjC1P6NHwnWGyMsvg" +
       "gix0qJcFz6ey8E984jug/c/zldfvNHBSIUI4Yoj/KAfnSO46mdXx+1iyL1\n" +
       "rPw5bG8+1Oy3J7oP2z95gYP+xtMO+lsD/foIetP6vlfV7z1VeHvQ5+6Mxx/8" +
       "X79g/Urxc59+9fYs\nim3Vd37z/HHM9562fOYQ5e2UXn9m4l95wcSFsizv8Y" +
       "Lf+4jukdMrsxfsFvyN3yYP+IlRWFy+SQsn\nUaLBe169H6nDomruAQ08ovtA" +
       "f/7HDPpTI+hD2zxGPfH8zHMgP3Vzt7t4evP33Qfy6z8+C3xtchuc\nvM9pP/" +
       "XQMaaN7t+5D9Y7v92wXnl4cHH6+83m5q0XnNOkescrp4OpU1isb+UbFHf7Su" +
       "+V7Xykdye6\nbxLIj2kS09jzEeDnngL4JD69COoUwcGJ7oP6vd8C1KfQfOYD" +
       "4X3jKby8lwdN+J4dtF0RufdgBx6K\nen4fdvZ3AvsnKs/xxpS7uTa34eGF1j" +
       "DtrIbug3nPAa3fdmvgcqfIRuniuSvf4b0P6hS5pl3o03kL\n+D6o5m8B6quP" +
       "u73ymQ8u1tdrL3cfy5S6B+iU15GJ7gN6zyms9wX6obtIfMvwo49Zffuh6u5j" +
       "NWWs\n95vXU9OfPwoyX35qd7rntFXUXJ+OL598PHf+bt/4e+b/KEwuJrpv/u" +
       "XvmKLefMp3R+tSRugvQjyJ\ncjrvgd6H+PrjyzdTPiTaqvLyZvqQxW0d83zi" +
       "+fxDfNhE9+H7Iz+WpP2UMLOH5cZDpFPSuWV+D9DJ\nHqejaMv7gP7s7wTQzz" +
       "4L9GE9+aznTEi/9AKkL6j1Jp+eTput7pvYn/wxl02fnObE4++zpJjOf64n\n" +
       "ug/iL06tH2lJ8XrljQ71UPnv8aLXH8ppOoj6U/cB+IsvBvBDZ7aPjSmjTL1b" +
       "f7kXyZQqvjvRfUj+\n7R9ZFJ9vc7e4P3G9KB9Mh0S/dx+af//H7RSTwD55sa" +
       "KG6hsvn44j3Yfzow/j9is3t2fy//jtP09I\nz0mPxXZMCeO7D5x3p+Tw1jvO" +
       "o29HBI++HfHtn0KWi59669xadXRui8Z75+6zDm9NtdFbceS/HeVd\nkXik5z" +
       "/1zY13vv3WTzdhVL/7ov8+vPPt7/7z337yXYpXfmVq/Yj/6HgBlvtEMv3j5Y" +
       "0nInnwQ4oE\nQpBnRVJF3fjkaZlEzSSDt/7A95W3npnof/RemxgBfPThCD9S" +
       "KPnYI863Mx5vfHgS9fRRjS++59NL\ndx8Icr7563/onV8t3/hP75bbjz7i8x" +
       "p/8zG/TdOnPwvxVPu1svL86HZKr919JOJ2fq/8+piX37uQ\nGaPL4/ZtrP6v" +
       "7nr/1xPgh72nv/9m+ahQeeoY3d1XLfr/Hx6N2JRCSgAA");
}
